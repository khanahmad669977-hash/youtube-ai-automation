#!/bin/bash

# YouTube AI Automation - Development Startup Script

echo "🚀 Starting YouTube AI Automation Development Environment"
echo "=================================================="

# Check if required directories exist
if [ ! -d "backend" ]; then
    echo "❌ Backend directory not found"
    exit 1
fi

if [ ! -d "worker" ]; then
    echo "❌ Worker directory not found"
    exit 1
fi

# Check if environment variables are set
if [ ! -f ".env.local" ]; then
    echo "⚠️  .env.local not found. Creating from template..."
    cp .env.example .env.local
    echo "📝 Please edit .env.local with your API keys"
fi

# Function to check if a port is in use
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1; then
        echo "❌ Port $1 is already in use"
        return 1
    else
        echo "✅ Port $1 is available"
        return 0
    fi
}

# Check ports
check_port 3000  # Frontend
check_port 8000  # Backend

echo ""
echo "🔧 Starting Services..."

# Start backend in background
echo "📡 Starting FastAPI Backend..."
cd backend
if [ ! -d "venv" ]; then
    echo "🐍 Creating Python virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -r requirements.txt > /dev/null 2>&1
uvicorn main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!
cd ..

# Wait for backend to start
echo "⏳ Waiting for backend to start..."
sleep 5

# Check backend health
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Backend is running on http://localhost:8000"
else
    echo "❌ Backend failed to start"
    kill $BACKEND_PID 2>/dev/null
    exit 1
fi

# Start worker in background
echo "🤖 Starting Video Worker..."
cd worker
if [ ! -d "venv" ]; then
    echo "🐍 Creating Python virtual environment for worker..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -r requirements.txt > /dev/null 2>&1
python main.py &
WORKER_PID=$!
cd ..

echo "✅ Worker started (PID: $WORKER_PID)"

# Start frontend
echo "🌐 Starting Next.js Frontend..."
npm run dev &
FRONTEND_PID=$!

echo ""
echo "🎉 All services started successfully!"
echo "=================================="
echo "📱 Frontend: http://localhost:3000"
echo "📡 Backend:  http://localhost:8000"
echo "📊 Backend Health: http://localhost:8000/health"
echo "🤖 Worker: Running in background"
echo ""
echo "📋 Service PIDs:"
echo "   Frontend: $FRONTEND_PID"
echo "   Backend:  $BACKEND_PID"
echo "   Worker:   $WORKER_PID"
echo ""
echo "🛑 To stop all services, press Ctrl+C"
echo "📝 Logs are being written to respective service terminals"

# Wait for interrupt signal
trap 'echo ""; echo "🛑 Stopping all services..."; kill $FRONTEND_PID $BACKEND_PID $WORKER_PID 2>/dev/null; echo "✅ All services stopped"; exit 0' INT

# Keep script running
wait