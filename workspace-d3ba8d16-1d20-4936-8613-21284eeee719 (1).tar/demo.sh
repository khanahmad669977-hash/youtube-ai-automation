#!/bin/bash

# Demo Script for YouTube AI Automation Agent
# This script demonstrates the complete pipeline

echo "🎬 YouTube AI Automation Agent - Demo Script"
echo "=============================================="

# Check if the development server is running
if ! curl -s http://localhost:3000 > /dev/null; then
    echo "❌ Development server is not running. Please run 'npm run dev' first."
    exit 1
fi

echo "✅ Development server is running"
echo ""

# Step 1: Create a test user
echo "👤 Step 1: Creating test user..."
USER_RESPONSE=$(curl -s -X POST http://localhost:3000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "demo@example.com",
    "password": "demo123456",
    "name": "Demo User"
  }')

TOKEN=$(echo $USER_RESPONSE | jq -r '.token')
USER_ID=$(echo $USER_RESPONSE | jq -r '.user.id')

if [ "$TOKEN" == "null" ]; then
    echo "❌ Failed to create user. Response: $USER_RESPONSE"
    exit 1
fi

echo "✅ User created successfully"
echo "   Email: demo@example.com"
echo "   User ID: $USER_ID"
echo ""

# Step 2: Configure settings
echo "⚙️ Step 2: Configuring automation settings..."
SETTINGS_RESPONSE=$(curl -s -X POST http://localhost:3000/api/settings/save \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "niche": "technology",
    "style": "educational",
    "voice": "male",
    "frequency": "weekly",
    "autoThumbnail": true,
    "autoSeo": true,
    "videoLength": "medium",
    "isActive": true
  }')

if echo "$SETTINGS_RESPONSE" | jq -e '.error' > /dev/null; then
    echo "❌ Failed to save settings: $SETTINGS_RESPONSE"
else
    echo "✅ Settings configured successfully"
fi
echo ""

# Step 3: Create a video job
echo "🎥 Step 3: Creating video job..."
JOB_RESPONSE=$(curl -s -X POST http://localhost:3000/api/videos/create \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN")

JOB_ID=$(echo $JOB_RESPONSE | jq -r '.jobId')

if [ "$JOB_ID" == "null" ]; then
    echo "❌ Failed to create job: $JOB_RESPONSE"
    exit 1
fi

echo "✅ Job created successfully"
echo "   Job ID: $JOB_ID"
echo ""

# Step 4: Run the AI pipeline (demo)
echo "🤖 Step 4: Running AI pipeline..."
echo "   This will demonstrate the complete video creation process..."

PIPELINE_RESPONSE=$(curl -s -X POST http://localhost:3000/api/demo/pipeline \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d "{\"jobId\": \"$JOB_ID\"}")

if echo "$PIPELINE_RESPONSE" | jq -e '.error' > /dev/null; then
    echo "❌ Pipeline failed: $PIPELINE_RESPONSE"
else
    echo "✅ Pipeline completed successfully!"
    VIDEO_URL=$(echo $PIPELINE_RESPONSE | jq -r '.videoUrl')
    echo "   Video URL: $VIDEO_URL"
fi
echo ""

# Step 5: Check job status
echo "📊 Step 5: Checking final job status..."
JOB_STATUS=$(curl -s -X GET http://localhost:3000/api/videos/list \
  -H "Authorization: Bearer $TOKEN")

echo "✅ Job status retrieved:"
echo "$JOB_STATUS" | jq '.jobs[0] | {id, status, title, progress, youtubeVideoId}'
echo ""

# Step 6: Display summary
echo "🎉 Demo Summary"
echo "==============="
echo "✅ Test user created: demo@example.com"
echo "✅ Settings configured for technology educational content"
echo "✅ Video job created and processed"
echo "✅ AI pipeline completed successfully"
echo ""
echo "📱 You can now:"
echo "   1. Visit http://localhost:3000/auth/login"
echo "   2. Login with demo@example.com / demo123456"
echo "   3. View your dashboard and created videos"
echo "   4. Configure YouTube channel (requires OAuth setup)"
echo ""
echo "🔗 API Endpoints tested:"
echo "   POST /api/auth/signup"
echo "   POST /api/settings/save"
echo "   POST /api/videos/create"
echo "   POST /api/demo/pipeline"
echo "   GET /api/videos/list"
echo ""
echo "🚀 Your YouTube AI Automation Agent is ready for deployment!"
echo "   See DEPLOYMENT.md for production deployment instructions."