import os
import json
import redis
import httpx
import asyncio
import uuid
from datetime import datetime
from supabase import create_client, Client
import tempfile
import requests
from moviepy.editor import *
from PIL import Image, ImageDraw, ImageFont
import io
import base64
import boto3
from botocore.exceptions import NoCredentialsError

# Configuration
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
R2_ACCESS_KEY = os.getenv("R2_ACCESS_KEY")
R2_SECRET_KEY = os.getenv("R2_SECRET_KEY")
R2_BUCKET_URL = os.getenv("R2_BUCKET_URL")
R2_BUCKET_NAME = os.getenv("R2_BUCKET_NAME", "youtube-automation")

# Initialize Redis
try:
    redis_client = redis.from_url(REDIS_URL, decode_responses=True)
    redis_client.ping()
    print("✅ Worker: Redis connected")
except Exception as e:
    print(f"❌ Worker: Redis connection failed: {e}")
    exit(1)

# Initialize Supabase
try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
    print("✅ Worker: Supabase connected")
except Exception as e:
    print(f"❌ Worker: Supabase connection failed: {e}")
    exit(1)

# Initialize Cloudflare R2 client
try:
    r2_client = boto3.client(
        's3',
        endpoint_url=R2_BUCKET_URL,
        aws_access_key_id=R2_ACCESS_KEY,
        aws_secret_access_key=R2_SECRET_KEY,
        region_name='auto'
    )
    print("✅ Worker: Cloudflare R2 connected")
except Exception as e:
    print(f"❌ Worker: R2 connection failed: {e}")
    exit(1)

class VideoWorker:
    def __init__(self):
        self.processing = False
    
    async def update_job_status(self, job_id: str, status: str, progress: int = None, log_message: str = None, error_message: str = None):
        """Update job status in database"""
        update_data = {
            "status": status,
            "updated_at": datetime.utcnow().isoformat()
        }
        
        if progress is not None:
            update_data["progress"] = progress
        
        if log_message:
            # Get current logs and append new message
            job_result = supabase.table("video_jobs").select("logs").eq("id", job_id).execute()
            if job_result.data:
                current_logs = job_result.data[0].get("logs", [])
                current_logs.append({
                    "timestamp": datetime.utcnow().isoformat(),
                    "message": log_message
                })
                update_data["logs"] = current_logs
        
        if error_message:
            update_data["error_message"] = error_message
        
        if status == "completed":
            update_data["completed_at"] = datetime.utcnow().isoformat()
        
        supabase.table("video_jobs").update(update_data).eq("id", job_id).execute()
        print(f"📊 Job {job_id} updated: {status} ({progress}%)" if progress else f"📊 Job {job_id} updated: {status}")
    
    async def generate_script(self, prompt: str, settings: dict) -> dict:
        """Generate video script using AI"""
        try:
            # For demo purposes, we'll use a simple script generation
            # In production, you'd use OpenAI, Claude, or other AI services
            
            script_data = {
                "title": f"Amazing {settings.get('niche', 'Technology')} Video",
                "description": f"An engaging video about {settings.get('niche', 'technology')}",
                "tags": ["technology", "ai", "automation", settings.get('niche', 'technology')],
                "script": [
                    {
                        "scene": 1,
                        "text": f"Welcome to this amazing video about {settings.get('niche', 'technology')}!",
                        "duration": 3
                    },
                    {
                        "scene": 2,
                        "text": f"Let's explore the fascinating world of {settings.get('niche', 'technology')}.",
                        "duration": 4
                    },
                    {
                        "scene": 3,
                        "text": f"This is why {settings.get('niche', 'technology')} is so important in our lives.",
                        "duration": 5
                    },
                    {
                        "scene": 4,
                        "text": f"Thank you for watching! Don't forget to like and subscribe.",
                        "duration": 3
                    }
                ]
            }
            }
            
            return script_data
            
        except Exception as e:
            print(f"❌ Script generation failed: {e}")
            raise e
    
    async def generate_tts(self, script: list, voice_type: str = "male") -> str:
        """Generate text-to-speech audio"""
        try:
            # For demo purposes, we'll create a silent audio file
            # In production, you'd use Coqui-TTS, HuggingFace TTS, or similar
            
            temp_dir = tempfile.mkdtemp()
            audio_path = os.path.join(temp_dir, "audio.wav")
            
            # Create a simple silent audio file (replace with actual TTS)
            audio_clip = ColorClip((640, 480), color=(0, 0, 0)).set_duration(15)
            audio_clip.write_videofile(audio_path.replace(".wav", ".mp4"), fps=24)
            
            print(f"🎵 TTS audio generated: {audio_path}")
            return audio_path
            
        except Exception as e:
            print(f"❌ TTS generation failed: {e}")
            raise e
    
    async def generate_images(self, script: list) -> list:
        """Generate images for video scenes"""
        try:
            images = []
            temp_dir = tempfile.mkdtemp()
            
            for i, scene in enumerate(script):
                # For demo purposes, create a simple colored image
                # In production, you'd use Stable Diffusion or similar
                
                image_path = os.path.join(temp_dir, f"scene_{i+1}.png")
                
                # Create a simple image with text
                img = Image.new('RGB', (1280, 720), color=(50 + i*50, 100, 150))
                draw = ImageDraw.Draw(img)
                
                # Add scene text
                try:
                    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 40)
                except:
                    font = ImageFont.load_default()
                
                text = scene["text"][:50] + "..." if len(scene["text"]) > 50 else scene["text"]
                draw.text((50, 300), text, fill=(255, 255, 255), font=font)
                
                img.save(image_path)
                images.append(image_path)
                print(f"🖼️ Image generated for scene {i+1}: {image_path}")
            
            return images
            
        except Exception as e:
            print(f"❌ Image generation failed: {e}")
            raise e
    
    async def generate_thumbnail(self, title: str) -> str:
        """Generate video thumbnail"""
        try:
            temp_dir = tempfile.mkdtemp()
            thumbnail_path = os.path.join(temp_dir, "thumbnail.png")
            
            # Create a simple thumbnail
            img = Image.new('RGB', (1280, 720), color=(220, 38, 127))
            draw = ImageDraw.Draw(img)
            
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 60)
            except:
                font = ImageFont.load_default()
            
            # Add title text
            title_lines = [title[i:i+30] for i in range(0, len(title), 30)]
            y_offset = 250
            for line in title_lines:
                draw.text((50, y_offset), line, fill=(255, 255, 255), font=font)
                y_offset += 70
            
            img.save(thumbnail_path)
            print(f"🖼️ Thumbnail generated: {thumbnail_path}")
            return thumbnail_path
            
        except Exception as e:
            print(f"❌ Thumbnail generation failed: {e}")
            raise e
    
    async def create_video(self, images: list, audio_path: str, script: list) -> str:
        """Create final video using MoviePy"""
        try:
            temp_dir = tempfile.mkdtemp()
            video_path = os.path.join(temp_dir, "final_video.mp4")
            
            # Create video clips from images
            clips = []
            for i, (image_path, scene) in enumerate(zip(images, script)):
                duration = scene.get("duration", 3)
                img_clip = ImageClip(image_path, duration=duration)
                
                # Add text overlay
                txt_clip = TextClip(
                    scene["text"],
                    fontsize=50,
                    color='white',
                    stroke_color='black',
                    stroke_width=2
                ).set_position('center').set_duration(duration)
                
                # Composite video and text
                video_clip = CompositeVideoClip([img_clip, txt_clip])
                clips.append(video_clip)
            
            # Concatenate all clips
            final_video = concatenate_videoclips(clips)
            
            # Add audio (for demo, we'll use the video's own audio)
            final_video.write_videofile(video_path, fps=24, codec='libx264', audio_codec='aac')
            
            print(f"🎬 Video created: {video_path}")
            return video_path
            
        except Exception as e:
            print(f"❌ Video creation failed: {e}")
            raise e
    
    async def upload_to_r2(self, file_path: str, file_key: str) -> str:
        """Upload file to Cloudflare R2"""
        try:
            r2_client.upload_file(
                file_path,
                R2_BUCKET_NAME,
                file_key,
                ExtraArgs={'ContentType': 'video/mp4' if file_path.endswith('.mp4') else 'image/png'}
            )
            
            file_url = f"{R2_BUCKET_URL}/{R2_BUCKET_NAME}/{file_key}"
            print(f"☁️ File uploaded to R2: {file_url}")
            return file_url
            
        except Exception as e:
            print(f"❌ R2 upload failed: {e}")
            raise e
    
    async def upload_to_youtube(self, video_path: str, title: str, description: str, tags: list, thumbnail_path: str, refresh_token: str) -> str:
        """Upload video to YouTube"""
        try:
            # Get new access token using refresh token
            token_data = {
                "client_id": os.getenv("GOOGLE_CLIENT_ID"),
                "client_secret": os.getenv("GOOGLE_CLIENT_SECRET"),
                "refresh_token": refresh_token,
                "grant_type": "refresh_token"
            }
            
            async with httpx.AsyncClient() as client:
                token_response = await client.post(
                    "https://oauth2.googleapis.com/token",
                    data=token_data
                )
                
                if token_response.status_code != 200:
                    raise Exception("Failed to refresh YouTube token")
                
                tokens = token_response.json()
                access_token = tokens["access_token"]
            
            # Upload video to YouTube
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json"
            }
            
            # First, get upload URL
            metadata = {
                "snippet": {
                    "title": title,
                    "description": description,
                    "tags": tags,
                    "categoryId": "22"  # Technology category
                },
                "status": {
                    "privacyStatus": "public",
                    "selfDeclaredMadeForKids": False
                }
            }
            
            async with httpx.AsyncClient() as client:
                # Start upload
                upload_response = await client.post(
                    "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
                    headers=headers,
                    json=metadata
                )
                
                if upload_response.status_code != 200:
                    raise Exception("Failed to start YouTube upload")
                
                upload_url = upload_response.headers.get("Location")
                if not upload_url:
                    raise Exception("No upload URL received from YouTube")
                
                # Upload video file
                with open(video_path, 'rb') as video_file:
                    upload_response = await client.put(
                        upload_url,
                        headers={"Content-Type": "video/mp4"},
                        content=video_file.read()
                    )
                
                if upload_response.status_code != 200:
                    raise Exception("Failed to upload video to YouTube")
                
                video_data = upload_response.json()
                video_id = video_data["id"]
                
                print(f"🎥 Video uploaded to YouTube: {video_id}")
                return f"https://www.youtube.com/watch?v={video_id}"
                
        except Exception as e:
            print(f"❌ YouTube upload failed: {e}")
            raise e
    
    async def process_job(self, job_data: dict):
        """Process a single video job"""
        job_id = job_data["job_id"]
        user_id = job_data["user_id"]
        prompt = job_data.get("prompt", "Create an amazing technology video")
        settings = job_data.get("settings", {})
        
        try:
            print(f"🚀 Processing job {job_id}")
            
            # Get user's YouTube refresh token
            user_result = supabase.table("users").select("youtube_refresh_token").eq("id", user_id).execute()
            if not user_result.data or not user_result.data[0]["youtube_refresh_token"]:
                raise Exception("No YouTube refresh token found for user")
            
            refresh_token = user_result.data[0]["youtube_refresh_token"]
            
            # Step 1: Generate script (10%)
            await self.update_job_status(job_id, "processing", 10, "Generating script...")
            script_data = await self.generate_script(prompt, settings)
            
            # Step 2: Generate TTS (30%)
            await self.update_job_status(job_id, "processing", 30, "Generating audio...")
            audio_path = await self.generate_tts(script_data["script"], settings.get("voice", "male"))
            
            # Step 3: Generate images (50%)
            await self.update_job_status(job_id, "processing", 50, "Generating images...")
            images = await self.generate_images(script_data["script"])
            
            # Step 4: Generate thumbnail (60%)
            await self.update_job_status(job_id, "processing", 60, "Generating thumbnail...")
            thumbnail_path = await self.generate_thumbnail(script_data["title"])
            
            # Step 5: Create video (80%)
            await self.update_job_status(job_id, "processing", 80, "Creating video...")
            video_path = await self.create_video(images, audio_path, script_data["script"])
            
            # Step 6: Upload to R2 (90%)
            await self.update_job_status(job_id, "processing", 90, "Uploading files...")
            video_key = f"videos/{job_id}/{uuid.uuid4()}.mp4"
            thumbnail_key = f"thumbnails/{job_id}/{uuid.uuid4()}.png"
            
            video_url = await self.upload_to_r2(video_path, video_key)
            thumbnail_url = await self.upload_to_r2(thumbnail_path, thumbnail_key)
            
            # Step 7: Upload to YouTube (100%)
            await self.update_job_status(job_id, "processing", 95, "Uploading to YouTube...")
            youtube_url = await self.upload_to_youtube(
                video_path, 
                script_data["title"], 
                script_data["description"], 
                script_data["tags"],
                thumbnail_path,
                refresh_token
            )
            
            # Extract YouTube video ID
            youtube_video_id = youtube_url.split("v=")[-1].split("&")[0] if "v=" in youtube_url else None
            
            # Update job as completed
            await self.update_job_status(job_id, "completed", 100, "Video completed successfully!")
            
            # Update database with final URLs
            supabase.table("video_jobs").update({
                "video_url": video_url,
                "thumbnail_url": thumbnail_url,
                "youtube_video_id": youtube_video_id,
                "youtube_url": youtube_url
            }).eq("id", job_id).execute()
            
            print(f"✅ Job {job_id} completed successfully!")
            
        except Exception as e:
            error_message = str(e)
            print(f"❌ Job {job_id} failed: {error_message}")
            await self.update_job_status(job_id, "failed", None, None, error_message)
    
    async def run(self):
        """Main worker loop"""
        print("🎬 Video Worker started. Waiting for jobs...")
        
        while True:
            try:
                # Get job from queue
                queue_data = redis_client.brpop("video_queue", timeout=10)
                
                if queue_data:
                    job_data = json.loads(queue_data[1])
                    print(f"📋 Received job: {job_data}")
                    
                    # Process the job
                    await self.process_job(job_data)
                else:
                    # No job in queue, wait a bit
                    await asyncio.sleep(1)
                    
            except Exception as e:
                print(f"❌ Worker error: {e}")
                await asyncio.sleep(5)  # Wait before retrying

if __name__ == "__main__":
    worker = VideoWorker()
    asyncio.run(worker.run())