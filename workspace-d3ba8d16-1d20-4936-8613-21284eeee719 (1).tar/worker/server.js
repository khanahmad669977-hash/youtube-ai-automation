const express = require('express');
const fs = require('fs');
const path = require('path');
const { Worker } = require('worker_threads');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3001;

// In-memory job queue (in production, use Redis)
const jobQueue = [];
const activeJobs = new Map();

// Worker function for video generation
function createVideoWorker() {
  return new Promise((resolve, reject) => {
    const worker = new Worker(`
      const { parentPort } = require('worker_threads');
      const fs = require('fs');
      const path = require('path');

      async function generateVideo(jobData) {
        try {
          parentPort.postMessage({ type: 'progress', jobId: jobData.jobId, message: 'Starting video generation...' });
          
          // Simulate different phases
          const phases = [
            { progress: 20, message: 'Generating script...' },
            { progress: 40, message: 'Creating audio...' },
            { progress: 60, message: 'Generating visuals...' },
            { progress: 80, message: 'Rendering video...' },
            { progress: 100, message: 'Video completed!' }
          ];

          for (const phase of phases) {
            await new Promise(r => setTimeout(r, 2000)); // 2 second delay per phase
            parentPort.postMessage({ 
              type: 'progress', 
              jobId: jobData.jobId, 
              progress: phase.progress, 
              message: phase.message 
            });
          }

          // Create a simple "video" file (just a text file for demo)
          const videoContent = \`
VIDEO TITLE: \${jobData.prompt}
CREATED AT: \${new Date().toISOString()}
STATUS: COMPLETED

This is a demo video file. In production, this would be an actual MP4 file.
          \`;

          const videoDir = path.join(__dirname, '../storage/videos');
          if (!fs.existsSync(videoDir)) {
            fs.mkdirSync(videoDir, { recursive: true });
          }

          const videoPath = path.join(videoDir, \`\${jobData.jobId}.mp4\`);
          fs.writeFileSync(videoPath, videoContent);

          parentPort.postMessage({ 
            type: 'completed', 
            jobId: jobData.jobId, 
            videoPath: \`/videos/\${jobData.jobId}.mp4\`,
            videoUrl: \`https://n0r75an8zq80-d.space.z.ai/videos/\${jobData.jobId}.mp4\`
          });

        } catch (error) {
          parentPort.postMessage({ 
            type: 'error', 
            jobId: jobData.jobId, 
            error: error.message 
          });
        }
      }

      parentPort.on('message', (message) => {
        if (message.type === 'generate') {
          generateVideo(message.data);
        }
      });

      parentPort.on('error', reject);
      parentPort.on('exit', resolve);
    `, { eval: true });

    worker.on('message', (message) => {
      if (message.type === 'completed') {
        resolve(message);
      } else if (message.type === 'error') {
        reject(new Error(message.error));
      }
    });

    worker.on('error', reject);
    worker.on('exit', resolve);
  });
}

// API endpoints
app.post('/generate', async (req, res) => {
  try {
    const { prompt, userId } = req.body;

    if (!prompt || !userId) {
      return res.status(400).json({ error: 'Prompt and userId required' });
    }

    const jobId = uuidv4();
    const jobData = { jobId, prompt, userId };

    // Add to queue
    jobQueue.push(jobData);

    // Process job if no active jobs
    if (activeJobs.size < 3) { // Max 3 concurrent jobs
      processNextJob();
    }

    res.json({
      message: 'Video generation job created',
      jobId,
      status: 'queued'
    });

  } catch (error) {
    console.error('Generate video error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/status/:jobId', (req, res) => {
  try {
    const { jobId } = req.params;
    const job = activeJobs.get(jobId);

    if (!job) {
      return res.status(404).json({ error: 'Job not found' });
    }

    res.json({
      jobId: job.jobId,
      status: job.status,
      progress: job.progress,
      message: job.message,
      videoUrl: job.videoUrl
    });

  } catch (error) {
    console.error('Get status error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/jobs', (req, res) => {
  try {
    const jobs = Array.from(activeJobs.values()).map(job => ({
      jobId: job.jobId,
      status: job.status,
      progress: job.progress,
      message: job.message,
      videoUrl: job.videoUrl,
      createdAt: job.createdAt
    }));

    res.json({ jobs });

  } catch (error) {
    console.error('List jobs error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Process next job in queue
async function processNextJob() {
  if (jobQueue.length === 0) return;

  const jobData = jobQueue.shift();
  
  activeJobs.set(jobData.jobId, {
    ...jobData,
    status: 'processing',
    progress: 0,
    message: 'Initializing...',
    createdAt: new Date().toISOString()
  });

  try {
    console.log(`🎬 Processing job ${jobData.jobId}: ${jobData.prompt}`);
    
    const result = await createVideoWorker();
    
    activeJobs.set(jobData.jobId, {
      ...activeJobs.get(jobData.jobId),
      status: 'completed',
      progress: 100,
      message: 'Video completed successfully!',
      videoUrl: result.videoUrl
    });

    console.log(`✅ Job ${jobData.jobId} completed: ${result.videoUrl}`);

    // Process next job in queue
    setTimeout(processNextJob, 1000);

  } catch (error) {
    console.error(`❌ Job ${jobData.jobId} failed:`, error);
    
    activeJobs.set(jobData.jobId, {
      ...activeJobs.get(jobData.jobId),
      status: 'failed',
      progress: 0,
      message: `Error: ${error.message}`,
      videoUrl: null
    });

    setTimeout(processNextJob, 5000); // Wait 5 seconds before next job
  }
}

// Serve static video files
app.use('/videos', express.static(path.join(__dirname, '../storage/videos')));

// Basic route for Railway testing
app.get('/', (req, res) => {
  res.json({ message: 'Worker OK', timestamp: new Date().toISOString() });
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    queueLength: jobQueue.length,
    activeJobs: activeJobs.size
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🎬 Video worker running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log(`📹 Video storage: http://localhost:${PORT}/videos`);
  
  // Create storage directory
  const storageDir = path.join(__dirname, '../storage/videos');
  if (!fs.existsSync(storageDir)) {
    fs.mkdirSync(storageDir, { recursive: true });
  }
  
  // Start job polling automatically
  console.log('🔄 Starting automatic job polling...');
  setInterval(() => {
    if (jobQueue.length > 0 && activeJobs.size < 3) {
      processNextJob();
    }
  }, 5000); // Check every 5 seconds
});