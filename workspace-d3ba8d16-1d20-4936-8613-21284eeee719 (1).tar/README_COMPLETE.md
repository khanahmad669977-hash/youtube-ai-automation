# 🎬 YouTube AI Automation Agent - Complete Production System

A fully functional, production-ready YouTube automation system that generates AI-powered videos and uploads them automatically to YouTube using only free-tier services.

## 🏗️ System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend     │    │    Backend     │    │     Worker     │    │   YouTube API  │
│   (Next.js)    │◄──►│   (FastAPI)    │◄──►│    (Python)    │◄──►│   (Google)     │
│   - Vercel     │    │   - Render      │    │   - Render      │    │   - Free       │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │                       │
         ▼                       ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Supabase     │    │   Upstash      │    │  Cloudflare R2  │    │   Users        │
│   (Database)    │    │   (Redis)      │    │   (Storage)    │    │   (YouTube)    │
│   - Free        │    │   - Free        │    │   - Free        │    │   - Free       │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

## ✨ Features

### 🎯 Core Functionality
- **AI Script Generation** - Automated video script creation
- **Text-to-Speech** - Voice generation using free TTS models
- **Image Generation** - AI-powered thumbnails and scenes
- **Video Rendering** - Professional video composition
- **YouTube Upload** - Automatic publishing to YouTube
- **User Management** - Authentication and channel management
- **Job Queue** - Scalable video processing pipeline
- **Real-time Progress** - Live job status tracking

### 🛠️ Technical Features
- **OAuth Integration** - Secure YouTube channel connection
- **RESTful API** - Complete backend with FastAPI
- **Responsive UI** - Modern frontend with Next.js
- **Database** - Supabase for data persistence
- **Queue System** - Redis for job management
- **File Storage** - Cloudflare R2 for media files
- **Error Handling** - Comprehensive error management
- **Logging** - Detailed system logging

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Python 3.8+
- Git
- Free accounts on: Vercel, Render, Supabase, Upstash, Cloudflare

### 1. Clone Repository
```bash
git clone <repository-url>
cd youtube-ai-automation
```

### 2. Development Setup
```bash
# Install frontend dependencies
npm install

# Set up environment
cp .env.example .env.local
# Edit .env.local with your API keys

# Start all services
./start-dev.sh
```

### 3. Access Applications
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

## 📁 Project Structure

```
youtube-ai-automation/
├── 📱 Frontend (Next.js)
│   ├── src/app/
│   │   ├── api/           # API proxies
│   │   ├── auth/          # Authentication pages
│   │   ├── dashboard/     # Main dashboard
│   │   ├── settings/      # Settings management
│   │   ├── videos/        # Video management
│   │   └── page.tsx       # Landing page
│   ├── components/ui/       # UI components
│   └── lib/              # Utilities
├── 🖥️ Backend (FastAPI)
│   ├── main.py            # Main application
│   ├── requirements.txt    # Dependencies
│   ├── render.yaml        # Render configuration
│   └── supabase_schema.sql # Database schema
├── 🤖 Worker (Python)
│   ├── main.py            # Worker process
│   ├── requirements.txt    # Dependencies
│   └── render.yaml        # Render configuration
├── 📚 Documentation
│   ├── README.md          # This file
│   ├── DEPLOYMENT_PRODUCTION.md
│   └── API.md
├── 🔧 Configuration
│   ├── .env.example       # Environment template
│   ├── .env.production    # Production variables
│   └── start-dev.sh      # Development script
└── 🌐 Deployment
    ├── vercel.json        # Vercel config
    └── render.yaml        # Render config
```

## 🔧 Configuration

### Environment Variables

Create `.env.local` for development:

```bash
# Frontend
NEXT_PUBLIC_APP_URL=http://localhost:3000
BACKEND_URL=http://localhost:8000

# Backend
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
YOUTUBE_REDIRECT_URI=http://localhost:3000/api/youtube/callback

# Database
SUPABASE_URL=your_supabase_url
SUPABASE_KEY=your_supabase_anon_key

# Security
JWT_SECRET=your_super_secret_jwt_key

# Queue
REDIS_URL=redis://localhost:6379

# Storage
R2_ACCESS_KEY=your_r2_access_key
R2_SECRET_KEY=your_r2_secret_key
R2_BUCKET_URL=https://your-account-id.r2.cloudflarestorage.com
R2_BUCKET_NAME=youtube-automation
```

### Service Setup

#### 1. Google Cloud Console
- Enable YouTube Data API v3
- Create OAuth 2.0 credentials
- Add redirect URI: `https://your-domain.com/api/youtube/callback`

#### 2. Supabase
- Create new project
- Run SQL schema from `backend/supabase_schema.sql`
- Get Project URL and Anon Key

#### 3. Upstash Redis
- Create Redis database
- Get REST URL and Token

#### 4. Cloudflare R2
- Create R2 bucket
- Generate API token with R2 permissions

## 🚀 Deployment

### Production Deployment

1. **Frontend to Vercel**:
   ```bash
   # Connect repository to Vercel
   # Set environment variables
   # Deploy automatically
   ```

2. **Backend to Render**:
   ```bash
   # Connect repository to Render
   # Use backend/render.yaml
   # Set environment variables
   ```

3. **Worker to Render**:
   ```bash
   # Connect repository to Render
   # Use worker/render.yaml
   # Set environment variables
   ```

### Manual Deployment

See `DEPLOYMENT_PRODUCTION.md` for detailed instructions.

## 📊 API Documentation

### Authentication Endpoints

#### POST /auth/signup
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "User Name"
}
```

#### POST /auth/login
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

### YouTube OAuth

#### GET /youtube/auth_url
Returns YouTube OAuth authorization URL.

#### GET /youtube/callback
Handles OAuth callback from Google.

### Video Management

#### POST /videos/create
```json
{
  "prompt": "Create a video about AI",
  "settings": {
    "niche": "technology",
    "style": "educational",
    "voice": "male",
    "video_length": "medium"
  }
}
```

#### GET /videos/{id}
Get video job status and download URL.

#### GET /jobs/{id}
Get detailed job logs and debugging info.

## 🎯 Video Generation Pipeline

### 1. Script Generation (10%)
- Uses AI to generate engaging video scripts
- Creates title, description, tags
- Breaks content into scenes

### 2. Audio Generation (30%)
- Converts script to speech using TTS
- Supports multiple voice types
- Optimized for YouTube

### 3. Image Generation (50%)
- Creates visuals for each scene
- Generates thumbnail
- Uses AI image models

### 4. Video Composition (80%)
- Combines images and audio
- Adds text overlays
- Professional rendering

### 5. YouTube Upload (100%)
- Uploads to YouTube automatically
- Uses stored refresh tokens
- Sets metadata and privacy

## 🔍 Monitoring

### Health Checks
- Backend: `/health`
- Database: Connection status
- Redis: Connection status
- Worker: Process status

### Logging
- Structured JSON logging
- Error tracking
- Performance metrics
- Job progress tracking

### Metrics to Monitor
- Video creation success rate
- YouTube upload success rate
- Processing time per video
- Error rates by service
- Resource utilization

## 🛡️ Security

### Authentication
- JWT-based authentication
- Secure password hashing
- OAuth 2.0 for YouTube
- Token refresh mechanism

### Data Protection
- Encrypted refresh tokens
- Secure API communication
- Input validation and sanitization
- Rate limiting

### Best Practices
- Environment variable management
- CORS configuration
- HTTPS everywhere
- Regular security updates

## 🔧 Troubleshooting

### Common Issues

1. **Backend Won't Start**
   - Check Python version (3.8+)
   - Verify dependencies installed
   - Check port availability

2. **Worker Not Processing Jobs**
   - Verify Redis connection
   - Check queue configuration
   - Review worker logs

3. **YouTube Upload Fails**
   - Check OAuth credentials
   - Verify refresh token
   - Review API quotas

4. **Database Connection Issues**
   - Verify Supabase URL
   - Check network connectivity
   - Review permissions

### Debug Mode

Enable debug logging:
```bash
DEBUG=true
LOG_LEVEL=debug
```

## 📈 Scaling

### Free Tier Limits
- Vercel: 100GB bandwidth/month
- Render: 750 hours/month
- Supabase: 500MB database
- Upstash: 10,000 requests/day
- Cloudflare R2: 10GB storage

### Upgrade Paths
- Vercel Pro: $20/month
- Render Pro: $25/month
- Supabase Pro: $25/month
- Upstash Pro: $5/month

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Make your changes
4. Add tests if applicable
5. Submit pull request

## 📄 License

MIT License - see LICENSE file for details.

## 🆘 Support

For issues and questions:
- Create GitHub issue
- Check documentation
- Review troubleshooting guide

## 🎉 Success Metrics

### System Performance
- Video creation: < 5 minutes
- Upload success: > 95%
- API response: < 200ms
- Uptime: > 99%

### User Experience
- Simple onboarding
- Real-time progress
- Mobile responsive
- Intuitive interface

---

## 🚀 Ready for Production!

This complete system includes:

✅ **Full Backend** - FastAPI with all endpoints
✅ **Video Worker** - Python pipeline for video creation  
✅ **Frontend** - Next.js with modern UI
✅ **Database** - Supabase integration
✅ **Queue System** - Redis for job processing
✅ **Storage** - Cloudflare R2 for files
✅ **OAuth** - YouTube channel integration
✅ **Deployment** - Production-ready configuration
✅ **Documentation** - Complete guides and API docs
✅ **Monitoring** - Health checks and logging

**Deploy today and start automating your YouTube channel!** 🎬✨