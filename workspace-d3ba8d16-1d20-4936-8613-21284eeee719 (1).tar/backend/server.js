const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const axios = require('axios');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? true 
    : ['http://localhost:3000'],
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('railway') ? { rejectUnauthorized: false } : false
});

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-change-in-production';

// YouTube OAuth configuration
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const YOUTUBE_REDIRECT_URI = process.env.YOUTUBE_REDIRECT_URI || 'https://n0r75an8zq80-d.space.z.ai/api/youtube/callback';

// Helper functions
function generateJWT(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

function verifyJWT(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

function hashPassword(password) {
  return bcrypt.hashSync(password, 10);
}

function comparePassword(password, hash) {
  return bcrypt.compareSync(password, hash);
}

// Database initialization
async function initializeDatabase() {
  try {
    // Create users table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255),
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create youtube_tokens table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS youtube_tokens (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        access_token TEXT,
        refresh_token TEXT,
        expires_in INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create jobs table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS jobs (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        status VARCHAR(50) DEFAULT 'pending',
        type VARCHAR(50),
        payload JSONB,
        result_url TEXT,
        error_message TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    console.log('✅ Database initialized successfully');
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
  }
}

// Authentication endpoints
app.post('/auth/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Check if user exists
    const existingUser = await pool.query(
      'SELECT id FROM users WHERE email = $1',
      [email]
    );

    if (existingUser.rows.length > 0) {
      return res.status(409).json({ error: 'User already exists' });
    }

    // Hash password
    const passwordHash = hashPassword(password);

    // Create user
    const result = await pool.query(
      'INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id',
      [name, email, passwordHash]
    );

    const userId = result.rows[0].id;
    const token = generateJWT({ userId, email });

    res.status(201).json({
      message: 'User created successfully',
      token,
      user: { id: userId, name, email }
    });

  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    // Find user
    const result = await pool.query(
      'SELECT id, name, email, password_hash FROM users WHERE email = $1',
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = result.rows[0];

    // Verify password
    if (!comparePassword(password, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateJWT({ userId: user.id, email: user.email });

    res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/auth/me', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = verifyJWT(token);
    if (!decoded) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    const result = await pool.query(
      'SELECT id, name, email FROM users WHERE id = $1',
      [decoded.userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user: result.rows[0] });

  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// YouTube OAuth endpoints
app.get('/youtube/auth_url', async (req, res) => {
  try {
    if (!GOOGLE_CLIENT_ID) {
      return res.status(500).json({ error: 'YouTube OAuth not configured' });
    }

    const state = crypto.randomBytes(16).toString('hex');
    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    
    authUrl.searchParams.set('client_id', GOOGLE_CLIENT_ID);
    authUrl.searchParams.set('redirect_uri', YOUTUBE_REDIRECT_URI);
    authUrl.searchParams.set('response_type', 'code');
    authUrl.searchParams.set('scope', 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube');
    authUrl.searchParams.set('access_type', 'offline');
    authUrl.searchParams.set('prompt', 'consent');
    authUrl.searchParams.set('state', state);

    res.json({ auth_url: authUrl.toString(), state });

  } catch (error) {
    console.error('YouTube auth URL error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/youtube/callback', async (req, res) => {
  try {
    const { code, state, error } = req.query;

    if (error) {
      return res.redirect(`https://n0r75an8zq80-d.space.z.ai/settings?error=${encodeURIComponent(error)}`);
    }

    if (!code) {
      return res.redirect('https://n0r75an8zq80-d.space.z.ai/settings?error=no_code');
    }

    // Exchange code for tokens
    const tokenResponse = await axios.post('https://oauth2.googleapis.com/token', {
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      code,
      grant_type: 'authorization_code',
      redirect_uri: YOUTUBE_REDIRECT_URI
    });

    const tokens = tokenResponse.data;

    // Get user info from YouTube
    const userResponse = await axios.get('https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true', {
      headers: {
        'Authorization': `Bearer ${tokens.access_token}`
      }
    });

    const channel = userResponse.data.items[0];
    
    // For demo purposes, we'll create or update a user with YouTube info
    // In a real app, you'd associate this with the logged-in user
    
    // Store tokens in database (associate with a user)
    const userId = 1; // This should come from the authenticated user's session
    
    await pool.query(
      'INSERT INTO youtube_tokens (user_id, access_token, refresh_token, expires_in) VALUES ($1, $2, $3, $4) ON CONFLICT (user_id) DO UPDATE SET access_token = $2, refresh_token = $3, expires_in = $4',
      [userId, tokens.access_token, tokens.refresh_token, tokens.expires_in]
    );

    // Redirect to frontend with success
    res.redirect(`https://n0r75an8zq80-d.space.z.ai/settings?success=youtube_connected&channel=${encodeURIComponent(channel.snippet.title)}`);

  } catch (error) {
    console.error('YouTube callback error:', error);
    res.redirect('https://n0r75an8zq80-d.space.z.ai/settings?error=oauth_failed');
  }
});

// Job management endpoints
app.post('/videos/generate', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = verifyJWT(token);
    if (!decoded) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    const { prompt, type = 'ai_video' } = req.body;

    // Create job
    const result = await pool.query(
      'INSERT INTO jobs (user_id, status, type, payload) VALUES ($1, $2, $3, $4) RETURNING id',
      [decoded.userId, 'pending', type, JSON.stringify({ prompt })]
    );

    const jobId = result.rows[0].id;

    // In a real implementation, you'd trigger the video creation worker here
    // For now, we'll simulate it
    setTimeout(async () => {
      try {
        // Update job status
        await pool.query(
          'UPDATE jobs SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          ['processing', jobId]
        );

        // Simulate video creation (in real app, this would call your worker)
        await new Promise(resolve => setTimeout(resolve, 5000));

        // Simulate completion
        const resultUrl = `https://n0r75an8zq80-d.space.z.ai/videos/${jobId}`;
        await pool.query(
          'UPDATE jobs SET status = $1, result_url = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
          ['completed', resultUrl, jobId]
        );

        console.log(`✅ Job ${jobId} completed`);
      } catch (error) {
        console.error(`❌ Job ${jobId} failed:`, error);
        await pool.query(
          'UPDATE jobs SET status = $1, error_message = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
          ['failed', error.message, jobId]
        );
      }
    }, 1000);

    res.json({
      message: 'Video generation job created',
      job_id: jobId,
      status: 'pending'
    });

  } catch (error) {
    console.error('Video generation error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/videos/:id', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = verifyJWT(token);
    if (!decoded) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    const { id } = req.params;

    const result = await pool.query(
      'SELECT * FROM jobs WHERE id = $1 AND user_id = $2',
      [id, decoded.userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Job not found' });
    }

    const job = result.rows[0];

    res.json({
      id: job.id,
      status: job.status,
      type: job.type,
      payload: job.payload,
      result_url: job.result_url,
      error_message: job.error_message,
      created_at: job.created_at,
      updated_at: job.updated_at
    });

  } catch (error) {
    console.error('Get video error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/jobs', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = verifyJWT(token);
    if (!decoded) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    const result = await pool.query(
      'SELECT * FROM jobs WHERE user_id = $1 ORDER BY created_at DESC',
      [decoded.userId]
    );

    res.json({
      jobs: result.rows.map(job => ({
        id: job.id,
        status: job.status,
        type: job.type,
        payload: job.payload,
        result_url: job.result_url,
        error_message: job.error_message,
        created_at: job.created_at,
        updated_at: job.updated_at
      }))
    });

  } catch (error) {
    console.error('List jobs error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// YouTube upload endpoint
app.post('/youtube/upload', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = verifyJWT(token);
    if (!decoded) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    const { videoPath, title, description, tags } = req.body;

    // Get user's YouTube tokens
    const tokenResult = await pool.query(
      'SELECT access_token, refresh_token FROM youtube_tokens WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1',
      [decoded.userId]
    );

    if (tokenResult.rows.length === 0) {
      return res.status(400).json({ error: 'No YouTube account connected' });
    }

    const { access_token, refresh_token } = tokenResult.rows[0];

    // For demo purposes, we'll simulate YouTube upload
    // In a real implementation, you'd use the YouTube Data API v3
    
    const videoId = `demo_${Date.now()}`;
    const youtubeUrl = `https://www.youtube.com/watch?v=${videoId}`;

    res.json({
      message: 'Video uploaded successfully',
      video_id: videoId,
      video_url: youtubeUrl
    });

  } catch (error) {
    console.error('YouTube upload error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    services: {
      database: 'connected',
      youtube_oauth: GOOGLE_CLIENT_ID ? 'configured' : 'not_configured'
    }
  });
});

// Basic route for Railway testing
app.get('/', (req, res) => {
  res.json({ message: 'Backend OK', timestamp: new Date().toISOString() });
});

// Initialize database and start server
async function startServer() {
  await initializeDatabase();
  
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Backend server running on port ${PORT}`);
    console.log(`📊 Health check: http://localhost:${PORT}/health`);
    console.log(`🔗 API documentation: http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);