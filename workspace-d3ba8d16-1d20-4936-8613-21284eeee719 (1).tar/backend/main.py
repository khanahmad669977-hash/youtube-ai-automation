from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, EmailStr
from typing import Optional, List
import os
import jwt
import bcrypt
import httpx
import redis
import json
import uuid
from datetime import datetime, timedelta
from supabase import create_client, Client
import hashlib

# Initialize FastAPI app
app = FastAPI(title="YouTube AI Automation Backend", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Environment variables
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
YOUTUBE_REDIRECT_URI = os.getenv("YOUTUBE_REDIRECT_URI", "https://n0r75an8zq80-d.space.z.ai/youtube/callback")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
JWT_SECRET = os.getenv("JWT_SECRET", "fallback-secret")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# Initialize Supabase
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Initialize Redis
try:
    redis_client = redis.from_url(REDIS_URL, decode_responses=True)
    redis_client.ping()
    print("✅ Redis connected successfully")
except Exception as e:
    print(f"❌ Redis connection failed: {e}")
    redis_client = None

# Pydantic models
class UserSignup(BaseModel):
    email: EmailStr
    password: str
    name: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class VideoCreateRequest(BaseModel):
    prompt: Optional[str] = None
    settings: Optional[dict] = None

# JWT functions
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=7)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, JWT_SECRET, algorithm="HS256")

def verify_token(token: str):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Dependency to get current user
async def get_current_user(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="No authorization header")
    
    token = auth_header.split(" ")[1]
    payload = verify_token(token)
    return payload

# Database helper functions
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

# YouTube OAuth endpoints
@app.get("/youtube/auth_url")
async def get_youtube_auth_url():
    """Generate YouTube OAuth authorization URL"""
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=500, detail="YouTube OAuth not configured")
    
    # Generate state parameter for security
    state = str(uuid.uuid4())
    
    # Store state in Redis temporarily
    if redis_client:
        redis_client.setex(f"oauth_state:{state}", 600, json.dumps({"created": datetime.utcnow().isoformat()}))
    
    # Build OAuth URL
    auth_url = (
        f"https://accounts.google.com/o/oauth2/v2/auth?"
        f"client_id={GOOGLE_CLIENT_ID}&"
        f"redirect_uri={YOUTUBE_REDIRECT_URI}&"
        f"response_type=code&"
        f"scope=https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube&"
        f"access_type=offline&"
        f"prompt=consent&"
        f"state={state}"
    )
    
    return {"auth_url": auth_url}

@app.get("/youtube/callback")
async def youtube_callback(code: str, state: str):
    """Handle YouTube OAuth callback"""
    try:
        # Verify state parameter
        if redis_client:
            state_data = redis_client.get(f"oauth_state:{state}")
            if not state_data:
                raise HTTPException(status_code=400, detail="Invalid or expired state")
            redis_client.delete(f"oauth_state:{state}")
        
        # Exchange authorization code for tokens
        token_data = {
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": YOUTUBE_REDIRECT_URI,
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://oauth2.googleapis.com/token",
                data=token_data
            )
            
            if response.status_code != 200:
                raise HTTPException(status_code=400, detail="Failed to exchange authorization code")
            
            tokens = response.json()
            
            # Get user info from YouTube
            headers = {"Authorization": f"Bearer {tokens['access_token']}"}
            user_response = await client.get(
                "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true",
                headers=headers
            )
            
            if user_response.status_code != 200:
                raise HTTPException(status_code=400, detail="Failed to get YouTube channel info")
            
            channel_data = user_response.json()
            if not channel_data.get("items"):
                raise HTTPException(status_code=400, detail("No YouTube channel found"))
            
            channel = channel_data["items"][0]
            channel_id = channel["id"]
            channel_name = channel["snippet"]["title"]
            channel_thumbnail = channel["snippet"]["thumbnails"]["default"]["url"]
            
            # For now, we'll need to get user_id from the state or session
            # In a real implementation, you'd store user_id in state or use a session
            # For demo purposes, we'll create a temporary user
            
            # Store refresh token (in production, encrypt this)
            refresh_token = tokens.get("refresh_token")
            if not refresh_token:
                raise HTTPException(status_code=400, detail="No refresh token received")
            
            # Store in database
            user_data = {
                "email": f"youtube_user_{channel_id}@example.com",
                "name": channel_name,
                "youtube_channel_id": channel_id,
                "youtube_channel_name": channel_name,
                "youtube_channel_thumbnail": channel_thumbnail,
                "youtube_refresh_token": refresh_token,
                "created_at": datetime.utcnow().isoformat()
            }
            
            # Insert into Supabase
            result = supabase.table("users").upsert(user_data).execute()
            
            # Create JWT token
            token = create_access_token({
                "user_id": result.data[0]["id"],
                "email": result.data[0]["email"],
                "channel_id": channel_id
            })
            
            # Redirect to dashboard with token
            redirect_url = f"https://n0r75an8zq80-d.space.z.ai/dashboard?token={token}"
            return RedirectResponse(url=redirect_url)
            
    except Exception as e:
        print(f"YouTube callback error: {e}")
        return RedirectResponse(
            url=f"https://n0r75an8zq80-d.space.z.ai/auth/login?error=oauth_failed"
        )

# Authentication endpoints
@app.post("/auth/signup")
async def signup(user_data: UserSignup):
    """User signup"""
    try:
        # Check if user already exists
        existing = supabase.table("users").select("*").eq("email", user_data.email).execute()
        if existing.data:
            raise HTTPException(status_code=400, detail="User already exists")
        
        # Hash password
        hashed_password = hash_password(user_data.password)
        
        # Create user
        new_user = {
            "email": user_data.email,
            "password": hashed_password,
            "name": user_data.name,
            "created_at": datetime.utcnow().isoformat()
        }
        
        result = supabase.table("users").insert(new_user).execute()
        
        # Create JWT token
        token = create_access_token({
            "user_id": result.data[0]["id"],
            "email": result.data[0]["email"]
        })
        
        return {
            "message": "User created successfully",
            "token": token,
            "user": {
                "id": result.data[0]["id"],
                "email": result.data[0]["email"],
                "name": result.data[0]["name"]
            }
        }
        
    except Exception as e:
        print(f"Signup error: {e}")
        raise HTTPException(status_code=500, detail="Signup failed")

@app.post("/auth/login")
async def login(user_data: UserLogin):
    """User login"""
    try:
        # Get user from database
        result = supabase.table("users").select("*").eq("email", user_data.email).execute()
        
        if not result.data:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        user = result.data[0]
        
        # Verify password
        if not verify_password(user_data.password, user["password"]):
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        # Create JWT token
        token = create_access_token({
            "user_id": user["id"],
            "email": user["email"]
        })
        
        return {
            "message": "Login successful",
            "token": token,
            "user": {
                "id": user["id"],
                "email": user["email"],
                "name": user["name"]
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Login error: {e}")
        raise HTTPException(status_code=500, detail="Login failed")

@app.get("/auth/me")
async def get_current_user_info(current_user: dict = Depends(get_current_user)):
    """Get current user info"""
    try:
        user_id = current_user["user_id"]
        result = supabase.table("users").select("*").eq("id", user_id).execute()
        
        if not result.data:
            raise HTTPException(status_code=404, detail="User not found")
        
        user = result.data[0]
        # Remove password from response
        user.pop("password", None)
        
        return {"user": user}
        
    except Exception as e:
        print(f"Get user error: {e}")
        raise HTTPException(status_code=500, detail="Failed to get user info")

# Video generation endpoints
@app.post("/videos/create")
async def create_video_job(
    request: VideoCreateRequest,
    current_user: dict = Depends(get_current_user)
):
    """Create a video generation job"""
    try:
        user_id = current_user["user_id"]
        
        # Create job record
        job_data = {
            "user_id": user_id,
            "status": "queued",
            "prompt": request.prompt,
            "settings": request.settings or {},
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
        
        result = supabase.table("video_jobs").insert(job_data).execute()
        job = result.data[0]
        
        # Add to Redis queue
        if redis_client:
            queue_data = {
                "job_id": job["id"],
                "user_id": user_id,
                "prompt": request.prompt,
                "settings": request.settings or {}
            }
            redis_client.lpush("video_queue", json.dumps(queue_data))
            print(f"✅ Job {job['id']} added to queue")
        
        return {
            "message": "Video job created successfully",
            "job_id": job["id"],
            "status": "queued"
        }
        
    except Exception as e:
        print(f"Create video job error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create video job")

@app.get("/videos/{job_id}")
async def get_video_status(
    job_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get video job status and download URL"""
    try:
        user_id = current_user["user_id"]
        
        # Get job from database
        result = supabase.table("video_jobs").select("*").eq("id", job_id).eq("user_id", user_id).execute()
        
        if not result.data:
            raise HTTPException(status_code=404, detail="Job not found")
        
        job = result.data[0]
        
        return {
            "job_id": job["id"],
            "status": job["status"],
            "progress": job.get("progress", 0),
            "video_url": job.get("video_url"),
            "thumbnail_url": job.get("thumbnail_url"),
            "youtube_video_id": job.get("youtube_video_id"),
            "created_at": job["created_at"],
            "completed_at": job.get("completed_at"),
            "error_message": job.get("error_message")
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Get video status error: {e}")
        raise HTTPException(status_code=500, detail="Failed to get video status")

@app.get("/jobs/{job_id}")
async def get_job_logs(
    job_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get job logs and detailed status for debugging"""
    try:
        user_id = current_user["user_id"]
        
        # Get job from database
        result = supabase.table("video_jobs").select("*").eq("id", job_id).eq("user_id", user_id).execute()
        
        if not result.data:
            raise HTTPException(status_code=404, detail="Job not found")
        
        job = result.data[0]
        
        return {
            "job_id": job["id"],
            "status": job["status"],
            "progress": job.get("progress", 0),
            "logs": job.get("logs", []),
            "settings": job.get("settings", {}),
            "prompt": job.get("prompt"),
            "created_at": job["created_at"],
            "updated_at": job.get("updated_at"),
            "completed_at": job.get("completed_at"),
            "error_message": job.get("error_message"),
            "video_url": job.get("video_url"),
            "thumbnail_url": job.get("thumbnail_url"),
            "youtube_video_id": job.get("youtube_video_id")
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Get job logs error: {e}")
        raise HTTPException(status_code=500, detail="Failed to get job logs")

@app.get("/videos")
async def list_user_videos(
    current_user: dict = Depends(get_current_user),
    limit: int = 20,
    offset: int = 0
):
    """List all videos for the current user"""
    try:
        user_id = current_user["user_id"]
        
        # Get videos from database
        result = supabase.table("video_jobs")\
            .select("*")\
            .eq("user_id", user_id)\
            .order("created_at", desc=True)\
            .range(offset, offset + limit - 1)\
            .execute()
        
        return {
            "videos": result.data,
            "total": len(result.data)
        }
        
    except Exception as e:
        print(f"List videos error: {e}")
        raise HTTPException(status_code=500, detail="Failed to list videos")

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    status = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {}
    }
    
    # Check Redis
    if redis_client:
        try:
            redis_client.ping()
            status["services"]["redis"] = "connected"
        except:
            status["services"]["redis"] = "disconnected"
    else:
        status["services"]["redis"] = "not_configured"
    
    # Check Supabase
    try:
        supabase.table("users").select("count").execute()
        status["services"]["supabase"] = "connected"
    except:
        status["services"]["supabase"] = "disconnected"
    
    return status

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)