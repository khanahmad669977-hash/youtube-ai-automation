# 🚀 YouTube AI Automation - Complete Deployment Guide

This guide will help you deploy the complete YouTube automation system with backend, worker, and frontend.

## 📋 Prerequisites

- Node.js 18+
- PostgreSQL 13+
- Redis (optional, for production)
- Free accounts on: Vercel, Render, Google Cloud, Cloudflare

## 🏗️ System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend     │    │    Backend     │    │     Worker     │
│   (Next.js)    │◄──►│   (Node.js)    │◄──►│    (Node.js)    │
│   - Vercel     │    │   - Render      │    │   - Render      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   PostgreSQL   │    │     Redis      │    │  Cloudflare R2  │
│   (Database)    │    │   (Queue)     │    │   (Storage)     │
│   - Render      │    │   - Upstash     │    │   - Cloudflare   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   YouTube API  │    │    Users        │    │   Generated     │
│   (Google)     │    │   (Auth)       │    │   Videos        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🔧 Setup Instructions

### 1. Clone and Install

```bash
git clone <your-repository>
cd youtube-ai-automation

# Install frontend dependencies
npm install

# Install backend dependencies
cd backend && npm install && cd ..

# Install worker dependencies
cd worker && npm install && cd ..
```

### 2. Configure Environment Variables

```bash
# Copy environment template
cp .env.template .env

# Edit .env with your actual values
nano .env
```

### 3. Set Up Database

```bash
# Start PostgreSQL
sudo systemctl start postgresql

# Create database
createdb youtube_automation

# Initialize database schema
psql -d youtube_automation -f backend/init_db.sql
```

### 4. Start Development Environment

```bash
# Start all services
chmod +x start-full-stack.sh
./start-full-stack.sh
```

## 🚀 Production Deployment

### Frontend (Vercel)

1. **Prepare for Deployment**
   ```bash
   # Build frontend
   npm run build
   ```

2. **Deploy to Vercel**
   ```bash
   # Install Vercel CLI
   npm i -g vercel

   # Deploy
   vercel --prod
   ```

3. **Configure Environment Variables**
   In Vercel Dashboard → Settings → Environment Variables:
   ```
   NEXT_PUBLIC_APP_URL=https://your-domain.vercel.app
   BACKEND_URL=https://your-backend.onrender.com
   ```

### Backend (Render)

1. **Create `backend/render.yaml`**
   ```yaml
   services:
     - type: web
       name: youtube-automation-backend
       env: node
       plan: free
       buildCommand: npm install
       startCommand: npm start
       envVars:
         - key: DATABASE_URL
           sync: false
         - key: GOOGLE_CLIENT_ID
           sync: false
         - key: GOOGLE_CLIENT_SECRET
           sync: false
         - key: JWT_SECRET
           generateValue: true
         - key: YOUTUBE_REDIRECT_URI
           value: https://your-domain.vercel.app/api/youtube/callback
   ```

2. **Deploy to Render**
   - Connect repository to Render
   - Use `backend/render.yaml` configuration
   - Set environment variables in Render dashboard

### Worker (Render)

1. **Create `worker/render.yaml`**
   ```yaml
   services:
     - type: worker
       name: youtube-automation-worker
       env: node
       plan: free
       buildCommand: npm install
       startCommand: npm start
       envVars:
         - key: BACKEND_URL
           sync: false
         - key: REDIS_URL
           sync: false
   ```

2. **Deploy to Render**
   - Connect repository to Render
   - Use `worker/render.yaml` configuration
   - Set environment variables

### Database (Render PostgreSQL)

1. **Create PostgreSQL Database**
   - In Render dashboard, create new PostgreSQL instance
   - Get connection string
   - Update `DATABASE_URL` in environment variables

2. **Run Database Migration**
   ```bash
   # Connect to your Render PostgreSQL database
   psql $DATABASE_URL -f backend/init_db.sql
   ```

### YouTube OAuth Setup

1. **Google Cloud Console**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create new project or select existing
   - Enable YouTube Data API v3
   - Create OAuth 2.0 credentials:
     - Application type: Web application
     - Authorized redirect URIs:
       - Development: `http://localhost:3000/api/youtube/callback`
       - Production: `https://your-domain.vercel.app/api/youtube/callback`

2. **Get Credentials**
   - Copy Client ID and Client Secret
   - Add to environment variables

### Redis (Upstash)

1. **Create Redis Database**
   - Go to [Upstash Console](https://console.upstash.com/)
   - Create new Redis database
   - Get REST URL and Token
   - Add to environment variables

### Cloudflare R2

1. **Create R2 Bucket**
   - Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
   - Create R2 Object Storage bucket
   - Generate API token with R2 permissions
   - Add credentials to environment variables

## 🔗 Service URLs

After deployment, your services will be available at:

- **Frontend**: `https://your-domain.vercel.app`
- **Backend API**: `https://your-backend.onrender.com`
- **API Documentation**: `https://your-backend.onrender.com/health`
- **Worker**: `https://your-worker.onrender.com`
- **Worker Health**: `https://your-worker.onrender.com/health`

## 🧪 Testing the Deployment

### 1. Health Checks

```bash
# Check backend health
curl https://your-backend.onrender.com/health

# Check worker health
curl https://your-worker.onrender.com/health
```

### 2. API Testing

```bash
# Test authentication
curl -X POST https://your-backend.onrender.com/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123"}'

# Test YouTube OAuth
curl https://your-backend.onrender.com/youtube/auth_url

# Test video generation
curl -X POST https://your-backend.onrender.com/videos/generate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{"prompt":"Create a test video"}'
```

### 3. Frontend Testing

1. Open `https://your-domain.vercel.app` in browser
2. Test user registration and login
3. Test YouTube OAuth connection
4. Test video generation and job status

## 🔧 Configuration Management

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `GOOGLE_CLIENT_ID` | YouTube OAuth client ID | Yes |
| `GOOGLE_CLIENT_SECRET` | YouTube OAuth client secret | Yes |
| `JWT_SECRET` | JWT signing secret | Yes |
| `YOUTUBE_REDIRECT_URI` | OAuth redirect URI | Yes |
| `REDIS_URL` | Redis connection string | Optional |
| `R2_ACCESS_KEY` | Cloudflare R2 access key | Optional |
| `R2_SECRET_KEY` | Cloudflare R2 secret key | Optional |

### Database Schema

The system uses these main tables:

- `users` - User accounts and authentication
- `youtube_tokens` - YouTube OAuth tokens
- `jobs` - Video generation jobs and status

## 🔍 Monitoring and Logging

### Backend Monitoring

```bash
# Check logs on Render
# View in Render dashboard

# Check health status
curl https://your-backend.onrender.com/health
```

### Worker Monitoring

```bash
# Check worker status
curl https://your-worker.onrender.com/health

# Monitor job processing
curl https://your-backend.onrender.com/jobs
```

### Frontend Monitoring

- Use Vercel Analytics
- Check browser console for errors
- Monitor API responses in Network tab

## 🛠️ Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check `DATABASE_URL` format
   - Ensure PostgreSQL is running
   - Verify network connectivity

2. **YouTube OAuth Fails**
   - Verify redirect URI matches exactly
   - Check Client ID and Secret
   - Ensure API is enabled in Google Cloud

3. **Worker Not Processing Jobs**
   - Check Redis connection
   - Verify worker is running
   - Check job queue status

4. **CORS Errors**
   - Check backend CORS configuration
   - Verify frontend URL in CORS origins
   - Ensure preflight requests are handled

5. **Build Failures**
   - Check Node.js version (18+)
   - Verify all dependencies are installed
   - Check for syntax errors in logs

### Debug Mode

Enable debug logging:
```bash
# Set environment variable
export DEBUG=true

# Check logs with more detail
npm start
```

## 📈 Scaling Considerations

### Free Tier Limits

| Service | Free Tier Limit | Upgrade Path |
|---------|-----------------|-------------|
| Vercel | 100GB bandwidth/month | Pro: $20/month |
| Render | 750 hours/month | Pro: $25/month |
| PostgreSQL | 512MB database | Pro: $25/month |
| Redis | 10K requests/day | Pro: $5/month |
| Cloudflare R2 | 10GB storage | Paid: $0.015/GB |

### When to Scale

1. **High Job Volume**: Add more worker instances
2. **Database Load**: Optimize queries, add indexes
3. **Storage Needs**: Upgrade R2 or use CDN
4. **API Rate Limits**: Implement caching and queuing

## 🔒 Security Best Practices

1. **Environment Variables**
   - Never commit secrets to git
   - Use different values for dev/prod
   - Rotate secrets regularly

2. **Database Security**
   - Use connection pooling
   - Implement proper indexing
   - Regular backups

3. **API Security**
   - Validate all inputs
   - Rate limit endpoints
   - Use HTTPS everywhere

4. **OAuth Security**
   - Validate state parameter
   - Use short-lived tokens
   - Store refresh tokens securely

## 🎯 Production Checklist

- [ ] Frontend deployed to Vercel
- [ ] Backend deployed to Render
- [ ] Worker deployed to Render
- [ ] Database created and migrated
- [ ] YouTube OAuth configured
- [ ] Environment variables set
- [ ] SSL certificates configured
- [ ] Health checks passing
- [ ] Monitoring enabled
- [ ] Error logging configured
- [ ] CORS properly configured
- [ ] Database connections working
- [ ] YouTube API integration tested
- [ ] Video generation pipeline tested
- [ ] User authentication working
- [ ] Job processing functional

## 🎉 Success Metrics

Monitor these metrics to ensure success:

- **User Registration Rate**: New signups per day
- **Video Generation Success**: % of jobs completed
- **YouTube Upload Success**: % of uploads successful
- **API Response Time**: Average response time
- **Error Rate**: % of requests failing
- **Resource Usage**: CPU, memory, storage

## 🆘 Support

For issues and questions:

1. **Documentation**: Check all README files
2. **Logs**: Review service logs
3. **Health Checks**: Monitor service status
4. **Community**: Create GitHub issues for bugs

---

## 🚀 Ready for Production!

Your YouTube AI Automation system is now complete with:

✅ **Full Backend API** - Authentication, OAuth, job management
✅ **Video Worker** - Asynchronous video processing
✅ **Database Integration** - PostgreSQL with proper schema
✅ **YouTube OAuth** - Complete Google OAuth flow
✅ **Frontend Integration** - Connected to real backend
✅ **Production Deployment** - Ready for Vercel + Render
✅ **Monitoring** - Health checks and logging
✅ **Security** - Best practices implemented

**Deploy today and start automating YouTube channels!** 🎬✨