import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';

export function middleware(request: NextRequest) {
  // Public paths that don't require authentication
  const publicPaths = [
    '/',
    '/auth/login',
    '/auth/signup',
    '/api/auth/login',
    '/api/auth/signup',
  ];

  const { pathname } = request.nextUrl;

  // Check if the path is public
  if (publicPaths.some(path => pathname.startsWith(path))) {
    return NextResponse.next();
  }

  // Check for protected routes
  if (pathname.startsWith('/dashboard') || 
      pathname.startsWith('/settings') || 
      pathname.startsWith('/videos') ||
      pathname.startsWith('/api/')) {
    
    // Get token from Authorization header or cookie
    const token = request.headers.get('Authorization')?.replace('Bearer ', '') ||
                 request.cookies.get('token')?.value;

    if (!token) {
      // Redirect to login for web routes
      if (pathname.startsWith('/dashboard') || 
          pathname.startsWith('/settings') || 
          pathname.startsWith('/videos')) {
        return NextResponse.redirect(new URL('/auth/login', request.url));
      }
      
      // Return 401 for API routes
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    try {
      // Verify JWT token
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret');
      
      // Add user info to request headers
      const response = NextResponse.next();
      response.headers.set('x-user-id', (decoded as any).userId);
      response.headers.set('x-user-email', (decoded as any).email);
      
      return response;
    } catch (error) {
      // Token is invalid
      if (pathname.startsWith('/dashboard') || 
          pathname.startsWith('/settings') || 
          pathname.startsWith('/videos')) {
        return NextResponse.redirect(new URL('/auth/login', request.url));
      }
      
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!_next/static|_next/image|favicon.ico|public).*)',
  ],
};