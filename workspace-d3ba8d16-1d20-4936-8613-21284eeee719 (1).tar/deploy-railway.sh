#!/bin/bash

# YouTube AI Automation - Railway Deployment Script

echo "🚀 Deploying YouTube AI Automation to Railway"
echo "============================================"

# Check if project is ready for Railway
if [ ! -d "backend" ] || [ ! -d "worker" ]; then
    echo "❌ Backend or worker directory not found"
    echo "Please run this from the project root directory"
    exit 1
fi

# Check if Railway CLI is installed
if ! command -v railway > /dev/null 2>&1; then
    echo "❌ Railway CLI not found"
    echo "Installing Railway CLI..."
    npm install -g @railway/cli
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install Railway CLI"
        exit 1
    fi
fi

# Function to check if Railway is logged in
check_railway_login() {
    if railway whoami > /dev/null 2>&1; then
        echo "✅ Railway CLI is logged in"
        return 0
    else
        echo "❌ Railway CLI is not logged in"
        echo "Please run: railway login"
        return 1
    fi
}

# Function to deploy backend
deploy_backend() {
    echo "📡 Deploying backend to Railway..."
    
    cd backend
    
    # Create temporary package.json for Railway
    cp package.json package.json.tmp
    
    # Update package.json for Railway
    cat > package.json << EOF
{
  "name": "youtube-automation-backend",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "engines": {
    "node": ">=18.0.0"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "pg": "^8.11.3",
    "axios": "^1.6.2",
    "dotenv": "^16.3.1"
  }
}
EOF
    
    # Deploy to Railway
    railway up --service-name youtube-automation-backend
    
    if [ $? -ne 0 ]; then
        echo "❌ Backend deployment failed"
        return 1
    else
        echo "✅ Backend deployed successfully"
        echo "🌐 Backend URL: https://youtube-automation-backend.railway.app"
    fi
    
    # Restore original package.json
    mv package.json.tmp package.json
    
    cd ..
}

# Function to deploy worker
deploy_worker() {
    echo "🤖 Deploying worker to Railway..."
    
    cd worker
    
    # Create temporary package.json for Railway
    cp package.json package.json.tmp
    
    # Update package.json for Railway
    cat > package.json << EOF
{
  "name": "youtube-automation-worker",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "engines": {
    "node": ">=18.0.0"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "axios": "^1.6.2",
    "dotenv": "^16.3.1"
  }
}
EOF
    
    # Deploy to Railway
    railway up --service-name youtube-automation-worker
    
    if [ $? -ne 0 ]; then
        echo "❌ Worker deployment failed"
        return 1
    else
        echo "✅ Worker deployed successfully"
        echo "🤖 Worker URL: https://youtube-automation-worker.railway.app"
    fi
    
    # Restore original package.json
    mv package.json.tmp package.json
    
    cd ..
}

# Main deployment function
deploy_to_railway() {
    echo "🚀 Starting Railway deployment..."
    
    # Check if logged in
    if ! check_railway_login; then
        echo "❌ Please login to Railway first"
        echo "Run: railway login"
        return 1
    fi
    
    # Deploy backend
    deploy_backend
    
    # Wait a bit between deployments
    sleep 3
    
    # Deploy worker
    deploy_worker
    
    echo ""
    echo "✅ Railway deployment completed!"
    echo "=================================="
    echo "🌐 Services deployed:"
    echo "   Backend: https://youtube-automation-backend.railway.app"
    echo "   Worker: https://youtube-automation-worker.railway.app"
    echo ""
    echo "📋 Next Steps:"
    echo "1. Set environment variables in Railway dashboard"
    echo "   - DATABASE_URL=postgresql://postgres:username:password@your-railway-db.railway.app:5432/your-database"
    echo "   - GOOGLE_CLIENT_ID=your_google_client_id"
    echo "   - GOOGLE_CLIENT_SECRET=your_google_client_secret"
    echo "   - YOUTUBE_REDIRECT_URI=https://n0r75an8zq80-d.space.z.ai/api/youtube/callback"
    echo "   - JWT_SECRET=your_super_secret_jwt_key"
    echo "   - BACKEND_URL=https://youtube-automation-backend.railway.app"
    echo "   - WORKER_URL=https://youtube-automation-worker.railway.app"
    echo "   - REDIS_URL=redis://your-redis-instance.upstash.io"
    echo "   - R2_ACCESS_KEY=your_r2_access_key"
    echo "   - R2_SECRET_KEY=your_r2_secret_key"
    echo "   - R2_BUCKET_URL=https://your-account-id.r2.cloudflarestorage.com"
    echo "   - R2_BUCKET_NAME=your-bucket-name"
    echo ""
    echo "🔧 Environment Variables:"
    echo "   NODE_ENV=production"
    echo "   DEBUG=false"
    echo ""
    echo "🎉 Testing Instructions:"
    echo "1. Test backend health: curl https://youtube-automation-backend.railway.app/health"
    echo "2. Test worker health: curl https://youtube-automation-worker.railway.app/"
    echo "3. Test API endpoints"
    echo "4. Test frontend integration"
}

# Check for command line arguments
if [ $# -eq 0 ]; then
    deploy_to_railway
else
    case "$1" in
        --interactive)
            echo "🎮 Interactive mode enabled"
            echo "Choose deployment option:"
            echo "1) Deploy both backend and worker"
            echo "2) Deploy backend only"
            echo "3) Deploy worker only"
            echo "4) Exit"
            echo ""
            read -p "Enter your choice (1-4): " choice
            case $choice in
                1)
                    deploy_to_railway
                    ;;
                2)
                    deploy_backend
                    ;;
                3)
                    deploy_worker
                    ;;
                4)
                    echo "Exiting..."
                    exit 0
                    ;;
                *)
                    echo "Invalid choice"
                    exit 1
                    ;;
            esac
            ;;
        --backend-only)
            echo "📡 Deploying backend only..."
            deploy_backend
            ;;
        --worker-only)
            echo "🤖 Deploying worker only..."
            deploy_worker
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 --interactive | --backend-only | --worker-only | --help"
            exit 1
            ;;
    esac
fi
}

# Show help
if [ "$1" == "--help" ]; then
    echo "📋 Railway Deployment Script Help"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --interactive    Interactive mode with deployment choices"
    echo "  --backend-only  Deploy only the backend service"
    echo "  --worker-only   Deploy only the worker service"
    echo "  --help        Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0                    # Interactive deployment"
    echo "  $0 --backend-only     # Deploy backend only"
    echo "  $0 --worker-only      # Deploy worker only"
fi
}

# Run main function
deploy_to_railway "$@"