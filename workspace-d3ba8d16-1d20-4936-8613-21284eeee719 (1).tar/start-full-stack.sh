#!/bin/bash

# YouTube AI Automation - Complete Startup Script

echo "🚀 Starting YouTube AI Automation - Full Stack"
echo "============================================="

# Check if required directories exist
if [ ! -d "backend" ]; then
    echo "❌ Backend directory not found"
    exit 1
fi

if [ ! -d "worker" ]; then
    echo "❌ Worker directory not found"
    exit 1
fi

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found. Creating from template..."
    cp .env.example .env
    echo "📝 Please edit .env with your API keys"
fi

# Function to check if a port is in use
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1; then
        echo "❌ Port $1 is already in use"
        return 1
    else
        echo "✅ Port $1 is available"
        return 0
    fi
}

# Check ports
check_port 8000  # Backend
check_port 3001  # Worker

echo ""
echo "🔧 Starting Services..."

# Start backend in background
echo "📡 Starting Backend API..."
cd backend

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing backend dependencies..."
    npm install > /dev/null 2>&1
fi

# Start database (PostgreSQL should be running)
echo "🗄️  Starting database connection..."
# You need to start PostgreSQL manually or use Docker

# Start backend server
npm start &
BACKEND_PID=$!
cd ..

# Wait for backend to start
echo "⏳ Waiting for backend to start..."
sleep 3

# Check backend health
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Backend is running on http://localhost:8000"
else
    echo "❌ Backend failed to start"
    kill $BACKEND_PID 2>/dev/null
    exit 1
fi

# Start worker in background
echo "🤖 Starting Video Worker..."
cd worker

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing worker dependencies..."
    npm install > /dev/null 2>&1
fi

npm start &
WORKER_PID=$!
cd ..

echo "✅ Worker started (PID: $WORKER_PID)"

# Start frontend
echo "🌐 Starting Frontend..."
npm run dev &
FRONTEND_PID=$!

echo ""
echo "🎉 All services started successfully!"
echo "=================================="
echo "📱 Frontend: http://localhost:3000"
echo "📡 Backend:  http://localhost:8000"
echo "🤖 Worker:  http://localhost:3001"
echo "📊 Backend Health: http://localhost:8000/health"
echo "📹 Worker Health: http://localhost:3001/health"
echo ""
echo "📋 Service PIDs:"
echo "   Frontend: $FRONTEND_PID"
echo "   Backend:  $BACKEND_PID"
echo "   Worker:   $WORKER_PID"
echo ""
echo "🛑 To stop all services, press Ctrl+C"
echo ""
echo "📝 Logs:"
echo "   Backend: Running in background"
echo "   Worker: Running in background"
echo "   Frontend: This terminal"

# Wait for interrupt signal
trap 'echo ""; echo "🛑 Stopping all services..."; kill $FRONTEND_PID $BACKEND_PID $WORKER_PID 2>/dev/null; echo "✅ All services stopped"; exit 0' INT

# Keep script running
wait