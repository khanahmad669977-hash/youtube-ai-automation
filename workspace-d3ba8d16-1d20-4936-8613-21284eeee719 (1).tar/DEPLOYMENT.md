# 🚀 Deployment Guide - Free YouTube AI Automation Agent

This guide will help you deploy the complete YouTube automation application using only free-tier services.

## 📋 Deployment Checklist

- [ ] Frontend deployed to Vercel
- [ ] Database configured (Supabase)
- [ ] Environment variables set
- [ ] YouTube OAuth configured
- [ ] Custom domain connected (optional)

## 🌐 Frontend Deployment (Vercel - Free)

### Step 1: Prepare Your Repository

1. **Push your code to GitHub**
   ```bash
   git add .
   git commit -m "Ready for deployment"
   git push origin main
   ```

2. **Create a GitHub repository** if you haven't already

### Step 2: Deploy to Vercel

1. **Sign up for Vercel** at [vercel.com](https://vercel.com)
2. **Import your repository**
   - Click "Add New..." → "Project"
   - Connect your GitHub account
   - Select your repository

3. **Configure the project**
   - Framework: Next.js (auto-detected)
   - Root Directory: ./
   - Build Command: `npm run build`
   - Output Directory: `.next`
   - Install Command: `npm install`

4. **Add Environment Variables**
   Go to Settings → Environment Variables and add:
   ```
   DATABASE_URL=your_supabase_connection_string
   JWT_SECRET=your_super_secret_jwt_key
   YOUTUBE_CLIENT_ID=your_youtube_client_id
   YOUTUBE_CLIENT_SECRET=your_youtube_client_secret
   NEXT_PUBLIC_APP_URL=https://your-domain.vercel.app
   ```

5. **Deploy**
   - Click "Deploy"
   - Wait for the build to complete
   - Your app will be live at `https://your-project-name.vercel.app`

### Step 3: Connect Custom Domain (Optional)

1. **Buy a domain** from any registrar (Hostinger, Namecheap, etc.)
2. **Add domain in Vercel**
   - Go to Project Settings → Domains
   - Add your custom domain
3. **Configure DNS**
   - Vercel will provide the DNS records
   - Add them to your domain registrar

## 🗄️ Database Setup (Supabase - Free)

### Step 1: Create Supabase Project

1. **Sign up for Supabase** at [supabase.com](https://supabase.com)
2. **Create a new project**
   - Choose a region closest to your users
   - Set a strong database password
   - Wait for the project to be ready

### Step 2: Get Connection String

1. **Go to Settings → Database**
2. **Copy the Connection string**
3. **Replace `[YOUR-PASSWORD]`** with your database password

### Step 3: Run Database Migrations

1. **Go to the SQL Editor** in Supabase
2. **Run the following SQL** to create your tables:

```sql
-- Create users table
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create channels table
CREATE TABLE channels (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  youtube_channel_id TEXT UNIQUE NOT NULL,
  youtube_channel_name TEXT NOT NULL,
  youtube_channel_thumbnail TEXT,
  refresh_token_encrypted TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create jobs table
CREATE TABLE jobs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  status TEXT DEFAULT 'QUEUED',
  progress INTEGER DEFAULT 0,
  logs TEXT,
  video_url TEXT,
  thumbnail_url TEXT,
  youtube_video_id TEXT,
  title TEXT,
  description TEXT,
  tags TEXT,
  error_message TEXT,
  started_at DATETIME,
  completed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE
);

-- Create settings table
CREATE TABLE settings (
  id TEXT PRIMARY KEY,
  user_id TEXT UNIQUE NOT NULL,
  niche TEXT,
  style TEXT,
  voice TEXT,
  frequency TEXT,
  auto_thumbnail BOOLEAN DEFAULT true,
  auto_seo BOOLEAN DEFAULT true,
  video_length TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### Step 4: Update Environment Variables

Update your Vercel environment variables:
```
DATABASE_URL=postgresql://postgres:[YOUR-PASSWORD]@db.[YOUR-PROJECT-REF].supabase.co:5432/postgres
```

## 🔐 YouTube OAuth Setup

### Step 1: Google Cloud Console

1. **Go to** [Google Cloud Console](https://console.cloud.google.com/)
2. **Create a new project** or select existing one
3. **Enable APIs**
   - YouTube Data API v3
   - Google OAuth2 API

### Step 2: Create OAuth Credentials

1. **Go to** Credentials → Create Credentials → OAuth 2.0 Client IDs
2. **Configure consent screen**
   - User Type: External
   - App name: "YouTube AI Automation"
   - User support email: your-email@example.com
   - Developer contact: your-email@example.com

3. **Create OAuth Client ID**
   - Application type: Web application
   - Name: "YouTube Automation Web"
   - Authorized redirect URIs:
     - `http://localhost:3000/api/youtube/callback` (development)
     - `https://your-domain.vercel.app/api/youtube/callback` (production)

### Step 3: Update Environment Variables

Add to your Vercel environment variables:
```
YOUTUBE_CLIENT_ID=your_client_id_here
YOUTUBE_CLIENT_SECRET=your_client_secret_here
```

## 🎯 Production Configuration

### Step 1: Security

1. **Generate a strong JWT secret**
   ```bash
   openssl rand -base64 32
   ```

2. **Update environment variables**
   ```
   JWT_SECRET=your_generated_secret_here
   ```

### Step 2: Performance Optimization

1. **Enable caching** in Vercel (automatic)
2. **Configure CDN** (automatic with Vercel)
3. **Set up monitoring** (Vercel Analytics)

## 📊 Monitoring & Analytics

### Vercel Analytics (Free Tier)

1. **Enable Analytics** in your Vercel project
2. **Monitor performance** and user behavior
3. **Set up alerts** for errors

### Supabase Dashboard

1. **Monitor database usage**
2. **Check query performance**
3. **Set up backups** (automatic)

## 🔧 Troubleshooting

### Common Issues

1. **Build fails**
   - Check environment variables
   - Verify all dependencies are installed
   - Check for TypeScript errors

2. **Database connection fails**
   - Verify connection string
   - Check if database is active
   - Ensure proper permissions

3. **YouTube OAuth fails**
   - Verify redirect URIs match exactly
   - Check if APIs are enabled
   - Ensure client ID and secret are correct

4. **Authentication fails**
   - Check JWT secret
   - Verify token storage
   - Check middleware configuration

### Debug Mode

Add this to your environment variables for debugging:
```
NODE_ENV=development
DEBUG=true
```

## 🚀 Going Live

### Pre-Launch Checklist

- [ ] All environment variables set
- [ ] Database tables created
- [ ] YouTube OAuth working
- [ ] SSL certificate active
- [ ] Domain properly configured
- [ ] Error monitoring set up
- [ ] Backup strategy in place

### Post-Launch

1. **Monitor performance** regularly
2. **Check error logs** daily
3. **Update dependencies** monthly
4. **Backup database** regularly
5. **Monitor usage limits**

## 💰 Cost Breakdown (All Free Tiers)

| Service | Cost | Limits |
|----------|------|--------|
| Vercel (Frontend) | $0 | 100GB bandwidth/month |
| Supabase (Database) | $0 | 500MB database, 2GB bandwidth |
| YouTube API | $0 | 10,000 units/day |
| ZAI SDK | $0 | Included in platform |
| **Total** | **$0** | **Suitable for small to medium usage** |

## 📈 Scaling Up

When you need to scale beyond free tiers:

1. **Vercel Pro** - $20/month for higher limits
2. **Supabase Pro** - $25/month for larger database
3. **Cloudflare R2** - $0.015/GB for storage beyond 10GB
4. **Dedicated server** - $5-20/month for worker processes

## 🔗 Useful Links

- [Vercel Documentation](https://vercel.com/docs)
- [Supabase Documentation](https://supabase.com/docs)
- [YouTube API Documentation](https://developers.google.com/youtube/v3)
- [Next.js Deployment Guide](https://nextjs.org/docs/deployment)

---

## 🎉 Congratulations!

You now have a fully functional YouTube automation application deployed using only free-tier services! 

Your application is ready to:
- Accept user registrations
- Connect YouTube channels
- Generate AI-powered videos
- Upload content automatically
- Scale with your business

For support or questions, refer to the main README or create an issue in the repository.