'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Youtube, 
  Play, 
  Settings, 
  BarChart3, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  Plus,
  ExternalLink,
  Calendar,
  TrendingUp,
  Video,
  Zap
} from 'lucide-react';

interface Job {
  id: string;
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  progress: number;
  title?: string;
  youtubeVideoId?: string;
  createdAt: string;
  completedAt?: string;
  errorMessage?: string;
}

interface Channel {
  id: string;
  youtubeChannelName: string;
  youtubeChannelThumbnail?: string;
  isActive: boolean;
}

export default function DashboardPage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreatingVideo, setIsCreatingVideo] = useState(false);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const token = localStorage.getItem('token');
      const [jobsResponse] = await Promise.all([
        fetch('/api/jobs', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
      ]);

      if (jobsResponse.ok) {
        const data = await jobsResponse.json();
        setJobs(data.jobs || []);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateVideo = async () => {
    setIsCreatingVideo(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/videos/generate', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: 'Create an amazing technology video',
          type: 'ai_video'
        }),
      });

      if (response.ok) {
        await fetchDashboardData(); // Refresh jobs list
      } else {
        console.error('Failed to create video');
      }
    } catch (error) {
      console.error('Error creating video:', error);
    } finally {
      setIsCreatingVideo(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'FAILED':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'QUEUED':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="w-4 h-4" />;
      case 'RUNNING':
        return <Loader2 className="w-4 h-4 animate-spin" />;
      case 'FAILED':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const completedJobs = jobs.filter(job => job.status === 'COMPLETED').length;
  const runningJobs = jobs.filter(job => job.status === 'RUNNING').length;
  const failedJobs = jobs.filter(job => job.status === 'FAILED').length;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Youtube className="w-6 h-6 text-red-600" />
            <span className="font-bold text-xl">YouTube AI Automation</span>
          </div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link href="/dashboard">Dashboard</Link>
            </Button>
            <Button variant="ghost" asChild>
              <Link href="/videos">Videos</Link>
            </Button>
            <Button variant="ghost" asChild>
              <Link href="/settings">Settings</Link>
            </Button>
            <Button 
              variant="outline"
              onClick={() => {
                localStorage.removeItem('token');
                window.location.href = '/auth/login';
              }}
            >
              Sign Out
            </Button>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome to Your Dashboard</h1>
          <p className="text-muted-foreground">
            Manage your YouTube automation and track your video creation progress
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Videos</CardTitle>
              <Video className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{completedJobs}</div>
              <p className="text-xs text-muted-foreground">
                Successfully uploaded
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{runningJobs}</div>
              <p className="text-xs text-muted-foreground">
                Currently processing
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Failed Jobs</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{failedJobs}</div>
              <p className="text-xs text-muted-foreground">
                Need attention
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Connected Channels</CardTitle>
              <Youtube className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{channels.length}</div>
              <p className="text-xs text-muted-foreground">
                YouTube channels
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Create and manage your video content
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={handleCreateVideo}
                  disabled={isCreatingVideo || channels.length === 0}
                  className="flex-1"
                >
                  {isCreatingVideo ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating Video...
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" />
                      Create New Video
                    </>
                  )}
                </Button>
                <Button variant="outline" asChild className="flex-1">
                  <Link href="/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    Configure Settings
                  </Link>
                </Button>
              </div>
              
              {channels.length === 0 && (
                <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                  <p className="text-sm text-yellow-800 dark:text-yellow-200">
                    <strong>No YouTube channels connected.</strong> Connect a channel to start creating videos.
                  </p>
                  <Button variant="outline" size="sm" className="mt-2" asChild>
                    <Link href="/settings">Connect Channel</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Connected Channels</CardTitle>
            </CardHeader>
            <CardContent>
              {channels.length > 0 ? (
                <div className="space-y-3">
                  {channels.map((channel) => (
                    <div key={channel.id} className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center">
                        <Youtube className="w-5 h-5 text-red-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{channel.youtubeChannelName}</p>
                        <p className="text-xs text-muted-foreground">
                          {channel.isActive ? 'Active' : 'Inactive'}
                        </p>
                      </div>
                      <Badge variant={channel.isActive ? 'default' : 'secondary'}>
                        {channel.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4">
                  <Youtube className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">No channels connected</p>
                  <Button variant="outline" size="sm" className="mt-2" asChild>
                    <Link href="/settings">Connect Channel</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Jobs */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Jobs</CardTitle>
                <CardDescription>
                  Track your video creation progress
                </CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link href="/videos">View All</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {jobs.length > 0 ? (
              <div className="space-y-4">
                {jobs.slice(0, 5).map((job) => (
                  <div key={job.id} className="flex items-center gap-4 p-4 border rounded-lg">
                    <div className="flex-shrink-0">
                      {getStatusIcon(job.status)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium truncate">
                          {job.title || `Video #${job.id.slice(-6)}`}
                        </p>
                        <Badge className={getStatusColor(job.status)}>
                          {job.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>Created: {new Date(job.createdAt).toLocaleDateString()}</span>
                        {job.completedAt && (
                          <span>Completed: {new Date(job.completedAt).toLocaleDateString()}</span>
                        )}
                        {job.youtubeVideoId && (
                          <Button variant="ghost" size="sm" asChild>
                            <a
                              href={`https://youtube.com/watch?v=${job.youtubeVideoId}`}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              <ExternalLink className="w-3 h-3 mr-1" />
                              View on YouTube
                            </a>
                          </Button>
                        )}
                      </div>
                      {job.status === 'RUNNING' && (
                        <div className="mt-2">
                          <Progress value={job.progress} className="h-2" />
                          <p className="text-xs text-muted-foreground mt-1">
                            {job.progress}% complete
                          </p>
                        </div>
                      )}
                      {job.errorMessage && (
                        <p className="text-sm text-red-600 dark:text-red-400 mt-1">
                          Error: {job.errorMessage}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Video className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">No jobs yet</p>
                <p className="text-sm text-muted-foreground mb-4">
                  Create your first video to get started
                </p>
                <Button onClick={handleCreateVideo} disabled={channels.length === 0}>
                  Create First Video
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}