import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import jwt from 'jsonwebtoken';

// GET /api/settings/get - Get user's settings
export async function GET(request: NextRequest) {
  try {
    // Get user ID from middleware headers
    const userId = request.headers.get('x-user-id');
    
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Fetch user's settings
    const settings = await db.settings.findUnique({
      where: { userId },
    });

    if (!settings) {
      // Create default settings if they don't exist
      const defaultSettings = await db.settings.create({
        data: {
          userId,
          niche: 'technology',
          style: 'educational',
          voice: 'male',
          frequency: 'weekly',
          autoThumbnail: true,
          autoSeo: true,
          videoLength: 'medium',
          isActive: true,
        },
      });

      return NextResponse.json({
        settings: {
          niche: defaultSettings.niche,
          style: defaultSettings.style,
          voice: defaultSettings.voice,
          frequency: defaultSettings.frequency,
          autoThumbnail: defaultSettings.autoThumbnail,
          autoSeo: defaultSettings.autoSeo,
          videoLength: defaultSettings.videoLength,
          isActive: defaultSettings.isActive,
        },
      });
    }

    return NextResponse.json({
      settings: {
        niche: settings.niche,
        style: settings.style,
        voice: settings.voice,
        frequency: settings.frequency,
        autoThumbnail: settings.autoThumbnail,
        autoSeo: settings.autoSeo,
        videoLength: settings.videoLength,
        isActive: settings.isActive,
      },
    });

  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}