import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import jwt from 'jsonwebtoken';
import { z } from 'zod';

const settingsSchema = z.object({
  niche: z.string().optional(),
  style: z.string().optional(),
  voice: z.string().optional(),
  frequency: z.string().optional(),
  autoThumbnail: z.boolean().optional(),
  autoSeo: z.boolean().optional(),
  videoLength: z.string().optional(),
  isActive: z.boolean().optional(),
});

// POST /api/settings/save - Save user's settings
export async function POST(request: NextRequest) {
  try {
    // Get user ID from middleware headers
    const userId = request.headers.get('x-user-id');
    
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const validatedData = settingsSchema.parse(body);

    // Update or create settings
    const settings = await db.settings.upsert({
      where: { userId },
      update: validatedData,
      create: {
        userId,
        ...validatedData,
      },
    });

    return NextResponse.json({
      message: 'Settings saved successfully',
      settings: {
        niche: settings.niche,
        style: settings.style,
        voice: settings.voice,
        frequency: settings.frequency,
        autoThumbnail: settings.autoThumbnail,
        autoSeo: settings.autoSeo,
        videoLength: settings.videoLength,
        isActive: settings.isActive,
      },
    });

  } catch (error) {
    console.error('Error saving settings:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input data' },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}