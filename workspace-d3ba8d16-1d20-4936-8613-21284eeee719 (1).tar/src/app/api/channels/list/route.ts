import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import jwt from 'jsonwebtoken';

// GET /api/channels/list - List all channels for the user
export async function GET(request: NextRequest) {
  try {
    // Get user ID from middleware headers
    const userId = request.headers.get('x-user-id');
    
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Fetch channels for the user
    const channels = await db.channel.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      channels: channels.map(channel => ({
        id: channel.id,
        youtubeChannelId: channel.youtubeChannelId,
        youtubeChannelName: channel.youtubeChannelName,
        youtubeChannelThumbnail: channel.youtubeChannelThumbnail,
        isActive: channel.isActive,
        createdAt: channel.createdAt.toISOString(),
      })),
    });

  } catch (error) {
    console.error('Error fetching channels:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}