import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/channels/[channelId]/disconnect - Disconnect a YouTube channel
export async function POST(
  request: NextRequest,
  { params }: { params: { channelId: string } }
) {
  try {
    // Get user ID from middleware headers
    const userId = request.headers.get('x-user-id');
    
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const channelId = params.channelId;

    // Verify the channel belongs to the user
    const channel = await db.channel.findFirst({
      where: {
        id: channelId,
        userId: userId,
      },
    });

    if (!channel) {
      return NextResponse.json(
        { error: 'Channel not found' },
        { status: 404 }
      );
    }

    // Delete the channel
    await db.channel.delete({
      where: { id: channelId },
    });

    return NextResponse.json({
      message: 'Channel disconnected successfully',
    });

  } catch (error) {
    console.error('Error disconnecting channel:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}