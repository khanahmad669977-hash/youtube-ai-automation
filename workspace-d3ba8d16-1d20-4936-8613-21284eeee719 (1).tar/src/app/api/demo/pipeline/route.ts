import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

// POST /api/demo/pipeline - Demo AI pipeline for video creation
export async function POST(request: NextRequest) {
  try {
    // Get user ID from middleware headers
    const userId = request.headers.get('x-user-id');
    
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { jobId } = await request.json();

    if (!jobId) {
      return NextResponse.json(
        { error: 'Job ID is required' },
        { status: 400 }
      );
    }

    // Get the job and user settings
    const job = await db.job.findUnique({
      where: { id: jobId },
      include: {
        user: {
          include: { settings: true }
        }
      }
    });

    if (!job) {
      return NextResponse.json(
        { error: 'Job not found' },
        { status: 404 }
      );
    }

    const settings = job.user.settings;
    if (!settings) {
      return NextResponse.json(
        { error: 'User settings not found' },
        { status: 404 }
      );
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();

    // Update job status to RUNNING
    await db.job.update({
      where: { id: jobId },
      data: { 
        status: 'RUNNING',
        startedAt: new Date(),
        progress: 10,
        logs: JSON.stringify({
          ...JSON.parse(job.logs || '{}'),
          pipeline_started: new Date().toISOString(),
          step: 'script_generation'
        })
      }
    });

    try {
      // Step 1: Generate Script using AI
      await db.job.update({
        where: { id: jobId },
        data: { 
          progress: 20,
          logs: JSON.stringify({
            ...JSON.parse(job.logs || '{}'),
            step: 'script_generation',
            message: 'Generating video script...'
          })
        }
      });

      const scriptPrompt = `Create a ${settings.videoLength} ${settings.style} YouTube video script about ${settings.niche}. The script should be engaging, informative, and suitable for a ${settings.voice} voice. Include a catchy title, description, and relevant tags.`;

      const scriptCompletion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a professional YouTube script writer. Create engaging, SEO-optimized video scripts.'
          },
          {
            role: 'user',
            content: scriptPrompt
          }
        ],
        max_tokens: 1000,
        temperature: 0.7,
      });

      const scriptContent = scriptCompletion.choices[0]?.message?.content || '';
      
      // Parse script content (in a real implementation, you'd parse this more carefully)
      const lines = scriptContent.split('\n');
      const title = lines.find(line => line.toLowerCase().includes('title:'))?.replace(/title:/i, '').trim() || `Amazing ${settings.niche} Video`;
      const description = lines.find(line => line.toLowerCase().includes('description:'))?.replace(/description:/i, '').trim() || `An amazing video about ${settings.niche}`;
      const tags = lines.filter(line => line.toLowerCase().includes('tag:')).map(line => line.replace(/tag:/i, '').trim()).slice(0, 10);

      await db.job.update({
        where: { id: jobId },
        data: { 
          progress: 40,
          title,
          description,
          tags: JSON.stringify(tags),
          logs: JSON.stringify({
            ...JSON.parse(job.logs || '{}'),
            step: 'script_completed',
            title,
            description,
            tags
          })
        }
      });

      // Step 2: Generate Thumbnail
      await db.job.update({
        where: { id: jobId },
        data: { 
          progress: 60,
          logs: JSON.stringify({
            ...JSON.parse(job.logs || '{}'),
            step: 'thumbnail_generation',
            message: 'Generating thumbnail...'
          })
        }
      });

      const thumbnailPrompt = `Create a YouTube thumbnail for: ${title}. Style: ${settings.style}, Niche: ${settings.niche}. Make it eye-catching and professional.`;

      try {
        const thumbnailResponse = await zai.images.generations.create({
          prompt: thumbnailPrompt,
          size: '1280x720'
        });

        const thumbnailBase64 = thumbnailResponse.data[0]?.base64;
        
        if (thumbnailBase64) {
          // In a real implementation, you'd upload this to Cloudflare R2
          const thumbnailUrl = `data:image/png;base64,${thumbnailBase64}`;
          
          await db.job.update({
            where: { id: jobId },
            data: { 
              thumbnailUrl,
              logs: JSON.stringify({
                ...JSON.parse(job.logs || '{}'),
                step: 'thumbnail_completed',
                thumbnailUrl
              })
            }
          });
        }
      } catch (imageError) {
        console.error('Thumbnail generation failed:', imageError);
        // Continue without thumbnail
      }

      // Step 3: Simulate Video Rendering
      await db.job.update({
        where: { id: jobId },
        data: { 
          progress: 80,
          logs: JSON.stringify({
            ...JSON.parse(job.logs || '{}'),
            step: 'video_rendering',
            message: 'Rendering video with AI-generated content...'
          })
        }
      });

      // Simulate video processing time
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Step 4: Simulate YouTube Upload
      await db.job.update({
        where: { id: jobId },
        data: { 
          progress: 90,
          logs: JSON.stringify({
            ...JSON.parse(job.logs || '{}'),
            step: 'youtube_upload',
            message: 'Uploading to YouTube...'
          })
        }
      });

      // Simulate YouTube upload and get a fake video ID
      const fakeVideoId = `demo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const videoUrl = `https://youtube.com/watch?v=${fakeVideoId}`;

      // Step 5: Complete the job
      await db.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          progress: 100,
          youtubeVideoId: fakeVideoId,
          videoUrl,
          completedAt: new Date(),
          logs: JSON.stringify({
            ...JSON.parse(job.logs || '{}'),
            step: 'completed',
            message: 'Video successfully created and uploaded!',
            youtubeVideoId: fakeVideoId,
            videoUrl
          })
        }
      });

      return NextResponse.json({
        message: 'Video pipeline completed successfully',
        jobId,
        youtubeVideoId: fakeVideoId,
        videoUrl
      });

    } catch (pipelineError) {
      console.error('Pipeline error:', pipelineError);
      
      // Update job with error
      await db.job.update({
        where: { id: jobId },
        data: { 
          status: 'FAILED',
          errorMessage: pipelineError instanceof Error ? pipelineError.message : 'Unknown error',
          logs: JSON.stringify({
            ...JSON.parse(job.logs || '{}'),
            step: 'failed',
            error: pipelineError instanceof Error ? pipelineError.message : 'Unknown error',
            timestamp: new Date().toISOString()
          })
        }
      });

      throw pipelineError;
    }

  } catch (error) {
    console.error('Demo pipeline error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}