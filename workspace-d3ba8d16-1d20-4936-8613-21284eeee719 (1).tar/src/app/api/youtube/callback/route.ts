import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    const error = searchParams.get('error');

    // Handle errors
    if (error) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL || 'https://n0r75an8zq80-d.space.z.ai'}/settings?error=${encodeURIComponent(error)}`
      );
    }

    if (!code) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL || 'https://n0r75an8zq80-d.space.z.ai'}/settings?error=no_code`
      );
    }

    // Forward to backend
    const backendUrl = `${process.env.BACKEND_URL || 'http://localhost:8000'}/youtube/callback?code=${encodeURIComponent(code)}&state=${encodeURIComponent(state || '')}`;

    // Redirect to backend to handle OAuth
    return NextResponse.redirect(backendUrl);

  } catch (error) {
    console.error('YouTube callback error:', error);
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL || 'https://n0r75an8zq80-d.space.z.ai'}/settings?error=oauth_failed`
    );
  }
}