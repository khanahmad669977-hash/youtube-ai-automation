'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Settings, 
  Youtube, 
  Save, 
  Link as LinkIcon,
  CheckCircle,
  AlertCircle,
  Loader2,
  ExternalLink,
  RefreshCw
} from 'lucide-react';

interface Channel {
  id: string;
  youtubeChannelId: string;
  youtubeChannelName: string;
  youtubeChannelThumbnail?: string;
  isActive: boolean;
}

interface AutomationSettings {
  niche: string;
  style: string;
  voice: string;
  frequency: string;
  autoThumbnail: boolean;
  autoSeo: boolean;
  videoLength: string;
  isActive: boolean;
}

export default function SettingsPage() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [settings, setSettings] = useState<AutomationSettings>({
    niche: 'technology',
    style: 'educational',
    voice: 'male',
    frequency: 'weekly',
    autoThumbnail: true,
    autoSeo: true,
    videoLength: 'medium',
    isActive: true,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isConnectingYoutube, setIsConnectingYoutube] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    fetchSettingsData();
  }, []);

  const fetchSettingsData = async () => {
    try {
      const token = localStorage.getItem('token');
      const [settingsResponse, channelsResponse] = await Promise.all([
        fetch('/api/settings/get', {
          headers: { 'Authorization': `Bearer ${token}` }
        }),
        fetch('/api/channels/list', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
      ]);

      if (settingsResponse.ok) {
        const settingsData = await settingsResponse.json();
        if (settingsData.settings) {
          setSettings(settingsData.settings);
        }
      }

      if (channelsResponse.ok) {
        const channelsData = await channelsResponse.json();
        setChannels(channelsData.channels || []);
      }
    } catch (error) {
      console.error('Failed to fetch settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    setIsSaving(true);
    setMessage(null);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/settings/save', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settings),
      });

      if (response.ok) {
        setMessage({ type: 'success', text: 'Settings saved successfully!' });
      } else {
        setMessage({ type: 'error', text: 'Failed to save settings' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'An error occurred while saving settings' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleConnectYoutube = async () => {
    setIsConnectingYoutube(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/youtube/auth_url', {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (response.ok) {
        const data = await response.json();
        // Redirect to YouTube OAuth URL
        window.location.href = data.auth_url;
      } else {
        setMessage({ type: 'error', text: 'Failed to get YouTube authorization URL' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'An error occurred while connecting YouTube' });
    } finally {
      setIsConnectingYoutube(false);
    }
  };

  const handleDisconnectChannel = async (channelId: string) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/channels/${channelId}/disconnect`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (response.ok) {
        setChannels(channels.filter(ch => ch.id !== channelId));
        setMessage({ type: 'success', text: 'Channel disconnected successfully' });
      } else {
        setMessage({ type: 'error', text: 'Failed to disconnect channel' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'An error occurred while disconnecting channel' });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Youtube className="w-6 h-6 text-red-600" />
            <span className="font-bold text-xl">YouTube AI Automation</span>
          </div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <a href="/dashboard">Dashboard</a>
            </Button>
            <Button variant="ghost" asChild>
              <a href="/videos">Videos</a>
            </Button>
            <Button variant="ghost" asChild>
              <a href="/settings">Settings</a>
            </Button>
            <Button 
              variant="outline"
              onClick={() => {
                localStorage.removeItem('token');
                window.location.href = '/auth/login';
              }}
            >
              Sign Out
            </Button>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Settings</h1>
          <p className="text-muted-foreground">
            Configure your automation preferences and manage your YouTube channels
          </p>
        </div>

        {message && (
          <Alert className={`mb-6 ${message.type === 'success' ? 'border-green-200 bg-green-50 dark:bg-green-900/20' : 'border-red-200 bg-red-50 dark:bg-red-900/20'}`}>
            {message.type === 'success' ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription>{message.text}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="automation" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="automation">Automation Settings</TabsTrigger>
            <TabsTrigger value="channels">YouTube Channels</TabsTrigger>
          </TabsList>

          <TabsContent value="automation">
            <Card>
              <CardHeader>
                <CardTitle>Automation Configuration</CardTitle>
                <CardDescription>
                  Customize how your AI-generated videos are created and scheduled
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="niche">Content Niche</Label>
                    <Select value={settings.niche} onValueChange={(value) => setSettings({...settings, niche: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a niche" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="health">Health & Fitness</SelectItem>
                        <SelectItem value="finance">Finance & Investing</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="entertainment">Entertainment</SelectItem>
                        <SelectItem value="gaming">Gaming</SelectItem>
                        <SelectItem value="cooking">Cooking & Food</SelectItem>
                        <SelectItem value="travel">Travel</SelectItem>
                        <SelectItem value="lifestyle">Lifestyle</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="science">Science</SelectItem>
                        <SelectItem value="history">History</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="style">Video Style</Label>
                    <Select value={settings.style} onValueChange={(value) => setSettings({...settings, style: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="educational">Educational</SelectItem>
                        <SelectItem value="motivational">Motivational</SelectItem>
                        <SelectItem value="entertaining">Entertaining</SelectItem>
                        <SelectItem value="informative">Informative</SelectItem>
                        <SelectItem value="storytelling">Storytelling</SelectItem>
                        <SelectItem value="tutorial">Tutorial</SelectItem>
                        <SelectItem value="review">Review</SelectItem>
                        <SelectItem value="news">News & Updates</SelectItem>
                        <SelectItem value="documentary">Documentary</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="voice">Voice Type</Label>
                    <Select value={settings.voice} onValueChange={(value) => setSettings({...settings, voice: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select voice type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male Voice</SelectItem>
                        <SelectItem value="female">Female Voice</SelectItem>
                        <SelectItem value="neutral">Neutral Voice</SelectItem>
                        <SelectItem value="energetic">Energetic Voice</SelectItem>
                        <SelectItem value="calm">Calm Voice</SelectItem>
                        <SelectItem value="professional">Professional Voice</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="frequency">Posting Frequency</Label>
                    <Select value={settings.frequency} onValueChange={(value) => setSettings({...settings, frequency: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="every_2_days">Every 2 Days</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="bi_weekly">Bi-Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="videoLength">Video Length</Label>
                    <Select value={settings.videoLength} onValueChange={(value) => setSettings({...settings, videoLength: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select video length" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="short">Short (30-60 seconds)</SelectItem>
                        <SelectItem value="medium">Medium (1-3 minutes)</SelectItem>
                        <SelectItem value="long">Long (3-10 minutes)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Auto-Generate Thumbnails</Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically generate thumbnails using AI
                      </p>
                    </div>
                    <Switch
                      checked={settings.autoThumbnail}
                      onCheckedChange={(checked) => setSettings({...settings, autoThumbnail: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Auto-SEO Optimization</Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically optimize titles, descriptions, and tags for SEO
                      </p>
                    </div>
                    <Switch
                      checked={settings.autoSeo}
                      onCheckedChange={(checked) => setSettings({...settings, autoSeo: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Enable Automation</Label>
                      <p className="text-sm text-muted-foreground">
                        Turn on automatic video creation and uploading
                      </p>
                    </div>
                    <Switch
                      checked={settings.isActive}
                      onCheckedChange={(checked) => setSettings({...settings, isActive: checked})}
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={handleSaveSettings} disabled={isSaving}>
                    {isSaving ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Save Settings
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="channels">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>YouTube Channels</CardTitle>
                    <CardDescription>
                      Connect and manage your YouTube channels for automatic uploads
                    </CardDescription>
                  </div>
                  <Button onClick={handleConnectYoutube} disabled={isConnectingYoutube}>
                    {isConnectingYoutube ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      <>
                        <LinkIcon className="mr-2 h-4 w-4" />
                        Connect YouTube
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {channels.length > 0 ? (
                  <div className="space-y-4">
                    {channels.map((channel) => (
                      <div key={channel.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center">
                            {channel.youtubeChannelThumbnail ? (
                              <img
                                src={channel.youtubeChannelThumbnail}
                                alt={channel.youtubeChannelName}
                                className="w-12 h-12 rounded-full object-cover"
                              />
                            ) : (
                              <Youtube className="w-6 h-6 text-red-600" />
                            )}
                          </div>
                          <div>
                            <h3 className="font-medium">{channel.youtubeChannelName}</h3>
                            <p className="text-sm text-muted-foreground">Channel ID: {channel.youtubeChannelId}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={channel.isActive ? 'default' : 'secondary'}>
                            {channel.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDisconnectChannel(channel.id)}
                          >
                            Disconnect
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Youtube className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No YouTube channels connected</h3>
                    <p className="text-muted-foreground mb-4">
                      Connect your YouTube channel to start uploading videos automatically
                    </p>
                    <Button onClick={handleConnectYoutube} disabled={isConnectingYoutube}>
                      {isConnectingYoutube ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Connecting...
                        </>
                      ) : (
                        <>
                          <LinkIcon className="mr-2 h-4 w-4" />
                          Connect YouTube Channel
                        </>
                      )}
                    </Button>
                  </div>
                )}

                <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h4 className="font-medium mb-2">How to connect your YouTube channel:</h4>
                  <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                    <li>Click the "Connect YouTube" button above</li>
                    <li>Sign in to your Google account</li>
                    <li>Grant permission to upload videos to your channel</li>
                    <li>Your channel will be automatically connected and ready to use</li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}