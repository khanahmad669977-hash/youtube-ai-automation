# 🚀 Production Deployment Guide

## Overview

This guide will help you deploy the complete YouTube AI Automation system to production using free-tier services.

## Architecture

```
Frontend (Next.js) → Backend (FastAPI) → Worker (Python) → YouTube API
     ↓                    ↓                    ↓
   Vercel              Render              Render/Colab
     ↓                    ↓                    ↓
   Supabase ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ← ←
   (Database + Auth)    (Redis Queue)     (Cloudflare R2)
```

## 1. Backend Deployment (Render)

### Create Render Service

1. **Create `render.yaml`** in your backend directory:
```yaml
services:
  - type: web
    name: youtube-automation-backend
    env: python
    plan: free
    buildCommand: pip install -r requirements.txt
    startCommand: uvicorn main:app --host 0.0.0.0 --port $PORT
    envVars:
      - key: GOOGLE_CLIENT_ID
        sync: false
      - key: GOOGLE_CLIENT_SECRET
        sync: false
      - key: YOUTUBE_REDIRECT_URI
        value: https://n0r75an8zq80-d.space.z.ai/api/youtube/callback
      - key: SUPABASE_URL
        sync: false
      - key: SUPABASE_KEY
        sync: false
      - key: JWT_SECRET
        generateValue: true
      - key: REDIS_URL
        sync: false
      - key: R2_ACCESS_KEY
        sync: false
      - key: R2_SECRET_KEY
        sync: false
      - key: R2_BUCKET_URL
        sync: false
      - key: R2_BUCKET_NAME
        value: youtube-automation
```

2. **Deploy to Render**:
   - Push code to GitHub
   - Connect repository to Render
   - Render will automatically deploy using `render.yaml`

### Manual Setup (Alternative)

1. Go to [Render Dashboard](https://render.com/)
2. Create New → Web Service
3. Connect your GitHub repository
4. Configure:
   - Name: `youtube-automation-backend`
   - Environment: `Python 3`
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - Instance Type: `Free`

## 2. Worker Deployment (Render)

### Create Worker Service

1. **Create `worker/render.yaml`**:
```yaml
services:
  - type: worker
    name: youtube-automation-worker
    env: python
    plan: free
    buildCommand: pip install -r requirements.txt
    startCommand: python main.py
    envVars:
      - key: REDIS_URL
        sync: false
      - key: SUPABASE_URL
        sync: false
      - key: SUPABASE_KEY
        sync: false
      - key: R2_ACCESS_KEY
        sync: false
      - key: R2_SECRET_KEY
        sync: false
      - key: R2_BUCKET_URL
        sync: false
      - key: R2_BUCKET_NAME
        value: youtube-automation
      - key: GOOGLE_CLIENT_ID
        sync: false
      - key: GOOGLE_CLIENT_SECRET
        sync: false
```

### Google Colab Alternative

1. **Create `worker/colab_worker.ipynb`** (Jupyter notebook)
2. Install dependencies and run worker
3. Use ngrok for external access (if needed)

## 3. Frontend Deployment (Vercel)

### Update Environment Variables

In Vercel Dashboard → Settings → Environment Variables:

```bash
NEXT_PUBLIC_APP_URL=https://n0r75an8zq80-d.space.z.ai
BACKEND_URL=https://your-backend-app.onrender.com
```

### Deploy

1. Connect repository to Vercel
2. Vercel automatically builds and deploys
3. Custom domain: Point DNS to Vercel

## 4. Database Setup (Supabase)

### Create Supabase Project

1. Go to [Supabase Dashboard](https://supabase.com/)
2. Create new project
3. Run the SQL schema from `backend/supabase_schema.sql`

### Get Connection Details

1. Settings → Database
2. Copy Project URL and Anon Key
3. Add to environment variables

## 5. Redis Setup (Upstash)

### Create Redis Database

1. Go to [Upstash Console](https://console.upstash.com/)
2. Create Redis Database
3. Get REST URL and Token
4. Add to environment variables

## 6. Cloudflare R2 Setup

### Create R2 Bucket

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. R2 Object Storage → Create Bucket
3. Create API Token with R2 permissions
4. Add credentials to environment variables

## 7. YouTube OAuth Setup

### Google Cloud Console

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create new project or select existing
3. Enable YouTube Data API v3
4. Create OAuth 2.0 Credentials:
   - Application type: Web application
   - Authorized redirect URIs:
     - `https://n0r75an8zq80-d.space.z.ai/api/youtube/callback`
5. Copy Client ID and Secret

## 8. Environment Configuration

### Production Environment Variables

Create `.env.production`:

```bash
# Frontend
NEXT_PUBLIC_APP_URL=https://n0r75an8zq80-d.space.z.ai
BACKEND_URL=https://your-backend.onrender.com

# Backend
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
YOUTUBE_REDIRECT_URI=https://n0r75an8zq80-d.space.z.ai/api/youtube/callback
SUPABASE_URL=your_supabase_url
SUPABASE_KEY=your_supabase_key
JWT_SECRET=your_jwt_secret
REDIS_URL=your_upstash_redis_url
R2_ACCESS_KEY=your_r2_access_key
R2_SECRET_KEY=your_r2_secret_key
R2_BUCKET_URL=https://your-account-id.r2.cloudflarestorage.com
R2_BUCKET_NAME=youtube-automation
```

## 9. DNS Configuration

### Point Domain to Services

1. **Frontend (Vercel)**:
   - CNAME: `@` → `cname.vercel-dns.com`
   - CNAME: `www` → `cname.vercel-dns.com`

2. **Backend (Render)**:
   - A record: `api` → Render service IP

## 10. Testing the Deployment

### Health Checks

1. **Backend Health**: `https://your-backend.onrender.com/health`
2. **Frontend**: `https://n0r75an8zq80-d.space.z.ai`
3. **Worker Logs**: Check Render dashboard

### End-to-End Test

1. Create user account
2. Connect YouTube channel
3. Create video job
4. Monitor worker processing
5. Check YouTube upload

## 11. Monitoring and Maintenance

### Logs and Monitoring

- **Frontend**: Vercel Analytics
- **Backend**: Render Logs
- **Worker**: Render Logs
- **Database**: Supabase Dashboard
- **Redis**: Upstash Console

### Scaling Considerations

- **Free Tier Limits**: Monitor usage
- **Upgrade Paths**: Ready for paid tiers
- **Performance**: Optimize as needed

## 12. Security Checklist

- [ ] Environment variables are set
- [ ] HTTPS is enabled everywhere
- [ ] YouTube OAuth redirect URIs are correct
- [ ] Database access is restricted
- [ ] API rate limiting is configured
- [ ] Error handling is in place
- [ ] Logging is enabled

## 13. Troubleshooting

### Common Issues

1. **CORS Errors**: Check backend CORS configuration
2. **OAuth Failures**: Verify redirect URIs
3. **Database Errors**: Check connection strings
4. **Worker Not Processing**: Check Redis connection
5. **Upload Failures**: Verify R2 credentials

### Debug Mode

Add to environment variables:
```bash
DEBUG=true
LOG_LEVEL=debug
```

## 14. Rollback Plan

### If Deployment Fails

1. **Frontend**: Vercel automatically rolls back
2. **Backend**: Redeploy previous commit
3. **Database**: Use backups
4. **Worker**: Restart service

## 15. Success Metrics

### Monitor These Metrics

- User registration rate
- Video creation success rate
- YouTube upload success rate
- Worker processing time
- Error rates
- Resource usage

---

## 🎉 Deployment Complete!

Your YouTube AI Automation system is now running on free-tier services:

- **Frontend**: Vercel (https://n0r75an8zq80-d.space.z.ai)
- **Backend**: Render (FastAPI)
- **Worker**: Render (Python)
- **Database**: Supabase
- **Queue**: Upstash Redis
- **Storage**: Cloudflare R2

The system is ready to handle video creation and YouTube automation!