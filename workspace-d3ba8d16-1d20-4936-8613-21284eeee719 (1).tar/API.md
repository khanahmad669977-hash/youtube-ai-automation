# 📚 API Documentation

## Base URL
```
Development: http://localhost:3000/api
Production: https://your-domain.com/api
```

## Authentication

All API endpoints (except auth endpoints) require a JWT token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## 🔐 Authentication Endpoints

### POST /auth/signup
Create a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "User Name"
}
```

**Response:**
```json
{
  "message": "User created successfully",
  "token": "jwt_token_here",
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name"
  }
}
```

### POST /auth/login
Authenticate user and get JWT token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "message": "Login successful",
  "token": "jwt_token_here",
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name"
  }
}
```

## ⚙️ Settings Endpoints

### GET /settings/get
Get user's automation settings.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "settings": {
    "niche": "technology",
    "style": "educational",
    "voice": "male",
    "frequency": "weekly",
    "autoThumbnail": true,
    "autoSeo": true,
    "videoLength": "medium",
    "isActive": true
  }
}
```

### POST /settings/save
Save user's automation settings.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "niche": "technology",
  "style": "educational",
  "voice": "male",
  "frequency": "weekly",
  "autoThumbnail": true,
  "autoSeo": true,
  "videoLength": "medium",
  "isActive": true
}
```

**Response:**
```json
{
  "message": "Settings saved successfully",
  "settings": {
    "niche": "technology",
    "style": "educational",
    "voice": "male",
    "frequency": "weekly",
    "autoThumbnail": true,
    "autoSeo": true,
    "videoLength": "medium",
    "isActive": true
  }
}
```

## 📺 Video Endpoints

### GET /videos/list
Get all video jobs for the authenticated user.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "jobs": [
    {
      "id": "job_id",
      "status": "COMPLETED",
      "progress": 100,
      "title": "Amazing Technology Video",
      "youtubeVideoId": "video_id",
      "createdAt": "2024-01-01T00:00:00.000Z",
      "completedAt": "2024-01-01T00:05:00.000Z",
      "channelName": "My YouTube Channel",
      "errorMessage": null
    }
  ]
}
```

### POST /videos/create
Create a new video job.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "message": "Video job created successfully",
  "jobId": "new_job_id",
  "status": "QUEUED"
}
```

## 📹 YouTube Channel Endpoints

### GET /channels/list
Get all connected YouTube channels.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "channels": [
    {
      "id": "channel_id",
      "youtubeChannelId": "youtube_channel_id",
      "youtubeChannelName": "My Channel",
      "youtubeChannelThumbnail": "thumbnail_url",
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00.000Z"
    }
  ]
}
```

### GET /youtube/auth-url
Get YouTube OAuth authorization URL.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "authUrl": "https://accounts.google.com/o/oauth2/v2/auth?..."
}
```

### GET /youtube/callback
Handle YouTube OAuth callback (redirect endpoint).

**Query Parameters:**
- `code`: Authorization code from Google
- `state`: JWT state parameter

**Redirects to:** `/settings?success=channel_connected` or `/settings?error=error_type`

### POST /channels/[channelId]/disconnect
Disconnect a YouTube channel.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "message": "Channel disconnected successfully"
}
```

## 🤖 Demo Pipeline Endpoint

### POST /demo/pipeline
Run the complete AI pipeline for a job (demo only).

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "jobId": "job_id"
}
```

**Response:**
```json
{
  "message": "Video pipeline completed successfully",
  "jobId": "job_id",
  "youtubeVideoId": "demo_video_id",
  "videoUrl": "https://youtube.com/watch?v=demo_video_id"
}
```

## 📊 Job Status Values

- `QUEUED`: Job is in queue waiting to be processed
- `RUNNING`: Job is currently being processed
- `COMPLETED`: Job finished successfully
- `FAILED`: Job failed with an error
- `CANCELLED`: Job was cancelled

## 🔧 Error Responses

All endpoints return error responses in the following format:

```json
{
  "error": "Error message description"
}
```

### Common HTTP Status Codes

- `200`: Success
- `201`: Created
- `400`: Bad Request (invalid input)
- `401`: Unauthorized (authentication required)
- `404`: Not Found
- `409`: Conflict (user already exists)
- `500`: Internal Server Error

## 🎯 Usage Examples

### Complete Video Creation Flow

```javascript
// 1. Login
const loginResponse = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'user@example.com',
    password: 'password123'
  })
});
const { token } = await loginResponse.json();

// 2. Create video job
const jobResponse = await fetch('/api/videos/create', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
});
const { jobId } = await jobResponse.json();

// 3. Run pipeline (demo)
const pipelineResponse = await fetch('/api/demo/pipeline', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ jobId })
});

// 4. Check job status
const statusResponse = await fetch('/api/videos/list', {
  headers: { 'Authorization': `Bearer ${token}` }
});
const { jobs } = await statusResponse.json();
```

## 🚀 Rate Limiting

- Authentication endpoints: 5 requests per minute
- Video creation: 10 requests per hour
- Other endpoints: 100 requests per minute

## 🔒 Security Notes

- JWT tokens expire after 7 days
- All passwords are hashed using bcrypt
- YouTube refresh tokens are encrypted
- CORS is configured for your domain
- Input validation on all endpoints

## 📱 SDK Examples

### JavaScript/TypeScript

```typescript
class YouTubeAutomationAPI {
  private baseURL: string;
  private token: string;

  constructor(baseURL: string, token: string) {
    this.baseURL = baseURL;
    this.token = token;
  }

  async createVideo(): Promise<string> {
    const response = await fetch(`${this.baseURL}/videos/create`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      }
    });
    const data = await response.json();
    return data.jobId;
  }

  async getJobs(): Promise<any[]> {
    const response = await fetch(`${this.baseURL}/videos/list`, {
      headers: { 'Authorization': `Bearer ${this.token}` }
    });
    const data = await response.json();
    return data.jobs;
  }
}
```

### Python

```python
import requests

class YouTubeAutomationAPI:
    def __init__(self, base_url, token):
        self.base_url = base_url
        self.headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }

    def create_video(self):
        response = requests.post(
            f'{self.base_url}/videos/create',
            headers=self.headers
        )
        return response.json()['jobId']

    def get_jobs(self):
        response = requests.get(
            f'{self.base_url}/videos/list',
            headers=self.headers
        )
        return response.json()['jobs']
```

---

For more information, see the main README.md or DEPLOYMENT.md files.